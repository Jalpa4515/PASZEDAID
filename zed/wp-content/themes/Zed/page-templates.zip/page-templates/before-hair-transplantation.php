<?php

/**
 * Template Name: Before Hair Transplantation Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>
<?php
$bgimg = wp_get_attachment_url(get_field('banner'));
?>
<!-- start banner-->

<section id="before-hair-transplant-banner" class="banner-wrapper common-banner-wrapper" style="background-image: url(<?= $bgimg; ?>);background-repeat: no-repeat ;background-position: center ;background-size: cover;">

    <div class="container banner-outer-container">

        <div class="banner-info">

            <h2>

                <span class="blue display-inline"><?= get_field('title_in_blue'); ?></span>

                <span class="white-color display-inline"> <?= get_field('title_in_black'); ?></span>

            </h2>

            <p class="white-color"><?= get_field('descriptions'); ?></p>

            <a href="<?= get_field('button_1_link') ? get_field('button_1_link') : "javascript:void(0)"; ?>" class="btn btn-primary-1"><?= get_field('button_1_title'); ?></a>

            <a href="<?= get_field('button_2_link') ? get_field('button_2_link') : "javascript:void(0)"; ?>" class="btn btn-secondary"><?= get_field('button_2_title'); ?></a>

        </div>
        <!-- <div class="banner-profile-image">
            <img src="<?php echo $bgimg; ?>" alt="Profile" />
        </div> -->

    </div>

</section>

<!-- end banner-->

<!-- start  breadcrumbs-->

<section class="breadcrumbs">

    <div class="container">

        <ul>

            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>

            <li class="active">Services</li>

        </ul>

    </div>

</section>

<!-- end breadcrumbs-->

<!-- start our exp section-->
<section class="our-exp-wrapper guidelines-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100 p-0">
                <span class="section-title default-title-spacing">Patient Guide</span>
                <h2>
                    <span class="blue display-inline">Read </span>
                    <span class="black display-inline">Guidelines</span>
                </h2>
                <ul class="guide-line-list">
                    <?php
                    if (get_field('guidelines')) :
                        $i = 1;
                        while (has_sub_field('guidelines')) :
                            $logoimage = wp_get_attachment_url(get_sub_field('image'));
                            ?>
                            <li class="guide-line-item">
                                <span class="guide-line-img">
                                    <img src="<?php echo $logoimage; ?>" alt="GuideLine" />
                                </span>
                                <div class="guide-line-text">
                                    <h5><?= get_sub_field('title'); ?></h5>
                                    <?= get_sub_field('descriptions'); ?>
                                </div>
                            </li>
                    <?php
                            $i++;
                        endwhile;
                    endif;
                    ?>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- end our exp section-->
<!-- start faq-->
<section class="our-exp-wrapper faq-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Our Support</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Frequently </span>
                    <span class="black display-inline">Asked Questions</span>
                </h2>
            </div>
            <div class="faq-inner-wrapper">
                <?php
                $args = array(
                    'post_type' => 'faq',
                    'posts_per_page' => 8 // this will retrive all the post that is published 
                );
                $result = new WP_Query($args);
                while ($result->have_posts()) : $result->the_post() ?>
                    <?php $tid = get_the_ID(); ?>
                    <div class="faq-item">
                        <h4 class="questions"><?= get_field('title', $tid); ?><span class="toggle-icon"></span></h4>
                        <div class="faq-body">
                            <?= get_field('descriptions', $tid); ?>
                        </div>
                    </div>
                <?php
                endwhile;
                wp_reset_postdata();
                $argss = array(
                                        'cat' => $t_post->term_id,
                                        'post_type' => 'faq',
                                        'posts_per_page' => -1 // this will retrive all the post that is published 
                                    );
                                    $results = new WP_Query($argss);
                if (count($results->posts) > 8) {
                    ?>
                    <div class="text-center view-more-t-center">
                        <a href="<?php echo BASE_URL ?>faq/" class="btn btn-primary btn-readmore">Know More <i class="fa fa-long-arrow-right"></i></a>
                    </div>
                <?php
                }
                ?>

            </div>
        </div>
    </div>
</section>
<!-- end faq-->
<section class="otherguideline-wrapper">
    <div class="container">
        <h2 class="mb-0">
            <span class="blue display-inline">Other </span>
            <span class="black display-inline">Guidelines</span>
        </h2>
        <div class="btn-group">
            <a href="<?= get_field('other_guidelines_button_1_link') ? get_field('other_guidelines_button_1_link') : "javascript:void(0)"; ?>" class="btn btn-secondary"><?= get_field('other_guidelines_button_title'); ?></a>
            <a href="<?= get_field('other_guidelines_button_2_link') ? get_field('other_guidelines_button_2_link') : "javascript:void(0)"; ?>" class="btn btn-secondary"><?= get_field('other_guidelines_button_2_title'); ?></a>
        </div>
    </div>
</section>
<!-- start free consultant section-->

<section class="free-consultant-wrapper">

    <div class="container">

        <div class="text-wrapper">

        <h2 class="white-color">Get your FREE CONSULTATION!</h2>

            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>
        </div>

        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">

            <span>

                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>

                <span class="text">Get free consultation</span>

                <i class="fa fa-chevron-right"></i>

            </span>

        </a>

    </div>

</section>

<!--end free consultant section-->

<?php
get_footer();
