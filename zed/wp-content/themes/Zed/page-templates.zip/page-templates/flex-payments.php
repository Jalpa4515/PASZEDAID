<?php

/**
 * Template Name:  Flex Payments Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>
<?php
$bgimg = wp_get_attachment_url(get_field('banner'));
$banner_upper_image = wp_get_attachment_url(get_field('banner_upper_image'));
?>
<!-- start banner-->
<section id="blue-magic-flex-payment" class="banner-wrapper common-banner-wrapper" style="background: url(<?= $bgimg; ?>) no-repeat left top !important; background-size: 100% 100% !important;">
    <div class="container banner-outer-container">
        <div class="banner-info">
            <h2>
                <span class="blue display-inline"><?= get_field('title_in_blue'); ?></span>
                <span class="white-color display-inline"><?= get_field('title_in_white'); ?></span>
            </h2>
            <p class="white-color"><?= get_field('descriptions'); ?></p>
            <a href="<?= get_field('button_1_link') ? get_field('button_1_link') : "javascript:void(0)"; ?>" class="btn btn-primary-1"><?= get_field('button_1_title'); ?></a>
            <a href="<?= get_field('button_2_link') ? get_field('button_2_link') : "javascript:void(0)"; ?>" class="btn btn-secondary-white"><?= get_field('button_2_title'); ?></a>
        </div>
        <div class="banner-profile-image">
            <img src="<?php echo bloginfo('template_directory'); ?>/images/flex-payment-profile.png" alt="Profile" />
        </div>
    </div>
</section>
<!-- end banner-->
<!-- start  breadcrumbs-->

<section class="breadcrumbs">
    <div class="container">
        <ul>
            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>
            <li class="active">Flex Payment</li>
        </ul>
    </div>
</section>

<!-- end breadcrumbs-->


<!-- start specialities service slider-->
<section class="our-exp-wrapper flex-payment-solution-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center"><span class="section-title two-lines">Flex Payments </span></div>
                <h2 class="text-center">
                    <span class="blue display-inline"><?= get_field('flex_payment_title_in_blue'); ?> </span>
                    <span class="black display-inline"><?= get_field('flex_payment_title_in_black'); ?></span>
                </h2>
                <p class="text-center mb-0"><?= get_field('flex_payment_descriptions'); ?></p>
                <div class="blocquote-wrapper">
                    <blockquote class="blockquote-text"><?= get_field('flex_payment_tagline_in_black'); ?><span class="blue"> <?= get_field('flex_payment_tagline_in_blue'); ?></span></blockquote>
                </div>
            </div>
        </div>
    </div>
    <div class="our-exp-bottom-container">
        <div class="container">
            <div class="finance-item">
                <span class="finance-img-wrapper">
                    <img src="<?php echo bloginfo('template_directory'); ?>/images/ideal-finance.png" alt="IdealFinance" />
                </span>
                <div class="finance-info-text">
                    <span class="section-title">For UK Patients </span>
                    <h2>
                        <span class="blue display-inline"><?= get_field('_flexible_payment_solutions_title_in_blue'); ?> </span>
                        <span class="black display-inline"><?= get_field('_flexible_payment_solutions_title_in_black'); ?></span>
                    </h2>
                    <p class="m-0"><?= get_field('_flexible_payment_solutions_desc'); ?></p>
                    <div class="finance-list-wrapper">
                        <h4><?= get_field('_flexible_payment_solutions_installments'); ?></h4>
                        <ul>
                            <?php
                            if (get_field('flexible_payment_solutions_process')) :
                                while (has_sub_field('flexible_payment_solutions_process')) :
                                    ?>
                                    <li>
                                        <i class="tick-icon"></i>
                                        <b><?= get_sub_field('title'); ?></b>
                                        <span><?= get_sub_field('subtitle'); ?></span>
                                    </li>
                            <?php
                                endwhile;
                            endif;
                            ?>
                        </ul>
                        <a href="https://ideal4finance.com/bluemagic?utm_source=3rd&utm_medium=banner&utm_campaign=Banners" class="btn btn-primary btn-readmore">Apply Now<i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="finance-item">
                <span class="finance-img-wrapper">
                    <img src="<?php echo bloginfo('template_directory'); ?>/images/display.png" alt="IdealFinance" />
                </span>
                <div class="finance-info-text">
                    <span class="section-title">For EU & Non-EU Patients </span>
                    <h2>
                        <span class="blue display-inline"><?= get_field('dila_pay_title_in_blue'); ?></span>
                        <span class="black display-inline pay"><?= get_field('dila_pay_title_in_black'); ?></span>
                    </h2>
                    <p class="m-0"><?= get_field('dila_pay_desc'); ?></p>
                    <div class="finance-list-wrapper">
                        <h4><?= get_field('dila_pay_instaallments'); ?></h4>

                        <?php
                        if (get_field('dilapay_process')) :
                            while (has_sub_field('dilapay_process')) :
                                ?>
                                <div class="d-flex flex-direction">
                                    <h5><?= get_sub_field('subprocess_title'); ?></h5>
                                    <ul>
                                        <?php
                                                if (get_sub_field('subprocess')) :
                                                    while (has_sub_field('subprocess')) :
                                                        ?>
                                                <li>
                                                    <i class="tick-icon"></i>
                                                    <b><?= get_sub_field('title'); ?></b>
                                                </li>
                                        <?php
                                                    endwhile;
                                                endif;
                                                ?>
                                    </ul>
                                </div>
                        <?php
                            endwhile;
                        endif;
                        ?>

                        <a href="https://www.dilapay.com/" class="btn btn-primary btn-readmore">Apply Now<i class="fa fa-long-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end specialities service slider-->
<!-- start before after service slider-->

<section class="our-exp-wrapper testimonial-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">Client Love Us</span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline">Patient </span>

                    <span class="black display-inline">Testimonials</span>

                </h2>

            </div>

        </div>

        <div class="rating-container">

            <div class="container">

                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/google.png" alt="Google"></a>

                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/trustpiolet.png" alt="Trust Piolet"></a>

                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/provenExport.png" alt="Proven Expert"></a>

            </div>

        </div>

        <div class="testimonial-slider-wrapper">

            <div class="container">

                <div class="testimonial-slider">

                    <?php
                    $args = array(
                        'post_type' => 'testimonials',
                        'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $resultt = new WP_Query($args);
                    while ($resultt->have_posts()) : $resultt->the_post();
                        $teid = get_the_ID();
                        ?>
                        <div>

                            <div class="slider-info">
                                
                                 <!--  viken - 22/01/2021 work start -->

                                <h5 class="display-inline"><?= get_field('testimonial_title', $teid); ?></h5>

                                <!--  viken - 22/01/2021 work end -->


                                <div class="slider-left">

                                    <?php $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>

                                    <img src="<?php echo $imagepv; ?>" alt="Testimonial" />

                                </div>

                                <?= get_field('descriptions', $teid); ?>

                                <h5 class="display-inline">- <?= get_field('full_name', $teid); ?></h5>
                                
                                <!--  viken - 22/01/2021 work start -->

                                <h5 class="display-inline">- <?= get_field('country_name', $teid); ?></h5>

                                <span class="flag-icon">

                                    <?php $flagIcon = wp_get_attachment_url(get_field('flag_icon', $teid)); ?>

                                    <img src="<?php echo $flagIcon; ?>" />

                                </span>
                                
                                </div>

                                <!--  viken - 22/01/2021 work end -->
                                

                        </div>

                    <?php endwhile;
                    wp_reset_postdata();
                    ?>


                </div>

            </div>

        </div>

        <div class="text-center view-more-t-center">

            <a href="<?= BASE_URL ?>testimonial/" class="btn btn-primary btn-readmore">View More <i class="fa fa-long-arrow-right"></i></a>

        </div>

    </div>

</section>
<!-- end before after service slider-->
<!-- start free consultant section-->
<section class="free-consultant-wrapper">
    <div class="container">
        <div class="text-wrapper">
        <h2 class="white-color">Get your FREE CONSULTATION!</h2>
            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>
        </div>
        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
            <span>
                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                <span class="text">Get free consultation</span>
                <i class="fa fa-chevron-right"></i>
            </span>
        </a>
    </div>
</section>
<!--end free consultant section-->

<?php
get_footer();
