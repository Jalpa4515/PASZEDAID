<?php

/**
 * Template Name:  Contact Us Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>
<?php
$bgimg = wp_get_attachment_url(get_field('banner'));
?>
<!-- start banner-->
<section id="contact-us-banner" class="banner-wrapper common-banner-wrapper" style="background-image: url(<?= $bgimg; ?>);background-repeat: no-repeat ;background-position: center ;background-size: cover;">
    <div class="container banner-outer-container">
        <div class="banner-info">
            <h2>
                <span class="blue display-inline"><?= get_field('title_in_blue'); ?></span>
                <span class="white-color display-inline"><?= get_field('title_in_white'); ?></span>
            </h2>
            <?= get_field('descriptions'); ?>
            <a href="<?= get_field('button_1_link'); ?>" class="btn btn-primary-1"><?= get_field('button_1_title'); ?></a>
        </div>
    </div>
</section>
<!-- end banner-->
<!-- start  breadcrumbs-->

<section class="breadcrumbs">
    <div class="container">
        <ul>
            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>
            <li class="active">Contact us</li>
        </ul>
    </div>
</section>

<!-- end breadcrumbs-->
<!-- start get inttouch form-->
<section class="our-exp-wrapper get-in-touch-wrapper">

    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel">
                <span class="section-title">Get In Touch</span>
                <h2>
                    <span class="blue">Dreaming of your <br /> beautiful hair already?</span>
                    <span class="black">Connect with us now!</span>
                </h2>
                <div class="get-in-touch-info">
                    <div class="get-in-touch-item">
                        <span class="icon-overlay">
                            <img src="<?php echo bloginfo('template_directory'); ?>/images/call-icon.png" alt="Call" />
                        </span>
                        <div class="icon-info-text">
                            <span>Phone</span>
                            <h5><a href="tel:<?php echo esc_attr(get_option('phonenumber')); ?>"><?php echo esc_attr(get_option('phonenumber')); ?></a></h5>
                        </div>
                    </div>
                    <div class="get-in-touch-item">
                        <span class="icon-overlay">
                            <img src="<?php echo bloginfo('template_directory'); ?>/images/mail-icon.png" alt="mail" />
                        </span>
                        <div class="icon-info-text">
                            <span>Email</span>
                            <h5><a href="mailto:<?php echo esc_attr(get_option('emailid')); ?>"><?php echo esc_attr(get_option('emailid')); ?></a></h5>
                        </div>
                    </div>
                    <div class="get-in-touch-item">
                        <span class="icon-overlay">
                            <img src="<?php echo bloginfo('template_directory'); ?>/images/clock-icon.png" alt="clock" />
                        </span>
                        <div class="icon-info-text">
                            <span>Open Hours</span>
                            <h5><?php echo esc_attr(get_option('openhours')); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-panel">
                <form name="contact-formm" method="POST">
                    <div class="form-group">
                        <i class="fa fa-user-o"></i>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Your Full Name" />
                        <span id="error_name"></span>
                    </div>
                    <div class="form-group">
                        <i class="fa fa-angle-down pn"></i>
                        <select class="form-control phone-number" id="county_code" name="county_code">
                            <option data-countryCode="GB" value="44">+44</option>
                            <option data-countryCode="CA" value="1">+1</option>
                            <option data-countryCode="IT" value="39">+39</option>
                            <option data-countryCode="AT" value="43">+43</option>
                            <option data-countryCode="AZ" value="994">+994</option>
                            <option data-countryCode="BS" value="1242">+1242</option>
                            <option data-countryCode="DZ" value="213">+213</option>
                            <option data-countryCode="AD" value="376">+376</option>
                            <option data-countryCode="AO" value="244">+244</option>
                            <option data-countryCode="AI" value="1264">+1264</option>
                            <option data-countryCode="AG" value="1268">+1268</option>
                            <option data-countryCode="AR" value="54">+54</option>
                            <option data-countryCode="AM" value="374">+374</option>
                            <option data-countryCode="AW" value="297">+297</option>
                            <option data-countryCode="AU" value="61">+61</option>
                            <option data-countryCode="BH" value="973">+973</option>
                            <option data-countryCode="BD" value="880">+880</option>
                            <option data-countryCode="BB" value="1246">+1246</option>
                            <option data-countryCode="BY" value="375">+375</option>
                            <option data-countryCode="BE" value="32">+32</option>
                            <option data-countryCode="BZ" value="501">+501</option>
                            <option data-countryCode="BJ" value="229">+229</option>
                            <option data-countryCode="BM" value="1441">+1441</option>
                            <option data-countryCode="BT" value="975">+975</option>
                            <option data-countryCode="BO" value="591">+591</option>
                            <option data-countryCode="BA" value="387">+387</option>
                            <option data-countryCode="BW" value="267">+267</option>
                            <option data-countryCode="BR" value="55">+55</option>
                            <option data-countryCode="BN" value="673">+673</option>
                            <option data-countryCode="BG" value="359">+359</option>
                            <option data-countryCode="BF" value="226">+226</option>
                            <option data-countryCode="BI" value="257">+257</option>
                            <option data-countryCode="KH" value="855">+855</option>
                            <option data-countryCode="CM" value="237">+237</option>
                            
                            <option data-countryCode="CV" value="238">+238</option>
                            <option data-countryCode="KY" value="1345">+1345</option>
                            <option data-countryCode="CF" value="236">+236</option>
                            <option data-countryCode="CL" value="56">+56</option>
                            <option data-countryCode="CN" value="86">+86</option>
                            <option data-countryCode="CO" value="57">+57</option>
                            <option data-countryCode="KM" value="269">+269</option>
                            <option data-countryCode="CG" value="242">+242</option>
                            <option data-countryCode="CK" value="682">+682</option>
                            <option data-countryCode="CR" value="506">+506</option>
                            <option data-countryCode="HR" value="385">+385</option>
                            <option data-countryCode="CU" value="53">+53</option>
                            <option data-countryCode="CY" value="90392">+90392</option>
                            <option data-countryCode="CY" value="357">+357</option>
                            <option data-countryCode="CZ" value="42">+42</option>
                            <option data-countryCode="DK" value="45">+45</option>
                            <option data-countryCode="DJ" value="253">+253</option>
                            <option data-countryCode="DM" value="1809">+1809</option>
                            <option data-countryCode="DO" value="1809">+1809</option>
                            <option data-countryCode="EC" value="593">+593</option>
                            <option data-countryCode="EG" value="20">+20</option>
                            <option data-countryCode="SV" value="503">+503</option>
                            <option data-countryCode="GQ" value="240">+240</option>
                            <option data-countryCode="ER" value="291">+291</option>
                            <option data-countryCode="EE" value="372">+372</option>
                            <option data-countryCode="ET" value="251">+251</option>
                            <option data-countryCode="FK" value="500">+500</option>
                            <option data-countryCode="FO" value="298">+298</option>
                            <option data-countryCode="FJ" value="679">+679</option>
                            <option data-countryCode="FI" value="358">+358</option>
                            <option data-countryCode="FR" value="33">+33</option>
                            <option data-countryCode="GF" value="594">+594</option>
                            <option data-countryCode="PF" value="689">+689</option>
                            <option data-countryCode="GA" value="241">+241</option>
                            <option data-countryCode="GM" value="220">+220</option>
                            <option data-countryCode="GE" value="7880">+7880</option>
                            <option data-countryCode="DE" value="49">+49</option>
                            <option data-countryCode="GH" value="233">+233</option>
                            <option data-countryCode="GI" value="350">+350</option>
                            <option data-countryCode="GR" value="30">+30</option>
                            <option data-countryCode="GL" value="299">+299</option>
                            <option data-countryCode="GD" value="1473">+1473</option>
                            <option data-countryCode="GP" value="590">+590</option>
                            <option data-countryCode="GU" value="671">+671</option>
                            <option data-countryCode="GT" value="502">+502</option>
                            <option data-countryCode="GN" value="224">+224</option>
                            <option data-countryCode="GW" value="245">+245</option>
                            <option data-countryCode="GY" value="592">+592</option>
                            <option data-countryCode="HT" value="509">+509</option>
                            <option data-countryCode="HN" value="504">+504</option>
                            <option data-countryCode="HK" value="852">+852</option>
                            <option data-countryCode="HU" value="36">+36</option>
                            <option data-countryCode="IS" value="354">+354</option>
                            <option data-countryCode="IN" value="91">+91</option>
                            <option data-countryCode="ID" value="62">+62</option>
                            <option data-countryCode="IR" value="98">+98</option>
                            <option data-countryCode="IQ" value="964">+964</option>
                            <option data-countryCode="IE" value="353">+353</option>
                            <option data-countryCode="IL" value="972">+972</option>
                            <option data-countryCode="JM" value="1876">+1876</option>
                            <option data-countryCode="JP" value="81">+81</option>
                            <option data-countryCode="JO" value="962">+962</option>
                            <option data-countryCode="KZ" value="7">+7</option>
                            <option data-countryCode="KE" value="254">+254</option>
                            <option data-countryCode="KI" value="686">+686</option>
                            <option data-countryCode="KP" value="850">+850</option>
                            <option data-countryCode="KR" value="82">+82</option>
                            <option data-countryCode="KW" value="965">+965</option>
                            <option data-countryCode="KG" value="996">+996</option>
                            <option data-countryCode="LA" value="856">+856</option>
                            <option data-countryCode="LV" value="371">+371</option>
                            <option data-countryCode="LB" value="961">+961</option>
                            <option data-countryCode="LS" value="266">+266</option>
                            <option data-countryCode="LR" value="231">+231</option>
                            <option data-countryCode="LY" value="218">+218</option>
                            <option data-countryCode="LI" value="417">+417</option>
                            <option data-countryCode="LT" value="370">+370</option>
                            <option data-countryCode="LU" value="352">+352</option>
                            <option data-countryCode="MO" value="853">+853</option>
                            <option data-countryCode="MK" value="389">+389</option>
                            <option data-countryCode="MG" value="261">+261</option>
                            <option data-countryCode="MW" value="265">+265</option>
                            <option data-countryCode="MY" value="60">+60</option>
                            <option data-countryCode="MV" value="960">+960</option>
                            <option data-countryCode="ML" value="223">+223</option>
                            <option data-countryCode="MT" value="356">+356</option>
                            <option data-countryCode="MH" value="692">+692</option>
                            <option data-countryCode="MQ" value="596">+596</option>
                            <option data-countryCode="MR" value="222">+222</option>
                            <option data-countryCode="YT" value="269">+269</option>
                            <option data-countryCode="MX" value="52">+52</option>
                            <option data-countryCode="FM" value="691">+691</option>
                            <option data-countryCode="MD" value="373">+373</option>
                            <option data-countryCode="MC" value="377">+377</option>
                            <option data-countryCode="MN" value="976">+976</option>
                            <option data-countryCode="MS" value="1664">+1664</option>
                            <option data-countryCode="MA" value="212">+212</option>
                            <option data-countryCode="MZ" value="258">+258</option>
                            <option data-countryCode="MN" value="95">+95</option>
                            <option data-countryCode="NA" value="264">+264</option>
                            <option data-countryCode="NR" value="674">+674</option>
                            <option data-countryCode="NP" value="977">+977</option>
                            <option data-countryCode="NL" value="31">+31</option>
                            <option data-countryCode="NC" value="687">+687</option>
                            <option data-countryCode="NZ" value="64">+64</option>
                            <option data-countryCode="NI" value="505">+505</option>
                            <option data-countryCode="NE" value="227">+227</option>
                            <option data-countryCode="NG" value="234">+234</option>
                            <option data-countryCode="NU" value="683">+683</option>
                            <option data-countryCode="NF" value="672">+672</option>
                            <option data-countryCode="NP" value="670">+670</option>
                            <option data-countryCode="NO" value="47">+47</option>
                            <option data-countryCode="OM" value="968">+968</option>
                            <option data-countryCode="PW" value="680">+680</option>
                            <option data-countryCode="PA" value="507">+507</option>
                            <option data-countryCode="PG" value="675">+675</option>
                            <option data-countryCode="PY" value="595">+595</option>
                            <option data-countryCode="PE" value="51">+51</option>
                            <option data-countryCode="PH" value="63">+63</option>
                            <option data-countryCode="PL" value="48">+48</option>
                            <option data-countryCode="PT" value="351">+351</option>
                            <option data-countryCode="PR" value="1787">+1787</option>
                            <option data-countryCode="QA" value="974">+974</option>
                            <option data-countryCode="RE" value="262">+262</option>
                            <option data-countryCode="RO" value="40">+40</option>
                            <option data-countryCode="RU" value="7">+7</option>
                            <option data-countryCode="RW" value="250">+250</option>
                            <option data-countryCode="SM" value="378">+378</option>
                            <option data-countryCode="ST" value="239">+239</option>
                            <option data-countryCode="SA" value="966">+966</option>
                            <option data-countryCode="SN" value="221">+221</option>
                            <option data-countryCode="CS" value="381">+381</option>
                            <option data-countryCode="SC" value="248">+248</option>
                            <option data-countryCode="SL" value="232">+232</option>
                            <option data-countryCode="SG" value="65">+65</option>
                            <option data-countryCode="SK" value="421">+421</option>
                            <option data-countryCode="SI" value="386">+386</option>
                            <option data-countryCode="SB" value="677">+677</option>
                            <option data-countryCode="SO" value="252">+252</option>
                            <option data-countryCode="ZA" value="27">+27</option>
                            <option data-countryCode="ES" value="34">+34</option>
                            <option data-countryCode="LK" value="94">+94</option>
                            <option data-countryCode="SH" value="290">+290</option>
                            <option data-countryCode="KN" value="1869">+1869</option>
                            <option data-countryCode="SC" value="1758">+1758</option>
                            <option data-countryCode="SD" value="249">+249</option>
                            <option data-countryCode="SR" value="597">+597</option>
                            <option data-countryCode="SZ" value="268">+268</option>
                            <option data-countryCode="SE" value="46">+46</option>
                            <option data-countryCode="CH" value="41">+41</option>
                            <option data-countryCode="SI" value="963">+963</option>
                            <option data-countryCode="TW" value="886">+886</option>
                            <option data-countryCode="TJ" value="7">+7</option>
                            <option data-countryCode="TH" value="66">+66</option>
                            <option data-countryCode="TG" value="228">+228</option>
                            <option data-countryCode="TO" value="676">+676</option>
                            <option data-countryCode="TT" value="1868">+1868</option>
                            <option data-countryCode="TN" value="216">+216</option>
                            <option data-countryCode="TR" value="90">+90</option>
                            <option data-countryCode="TM" value="7">+7</option>
                            <option data-countryCode="TM" value="993">+993</option>
                            <option data-countryCode="TC" value="1649">+1649</option>
                            <option data-countryCode="TV" value="688">+688</option>
                            <option data-countryCode="UG" value="256">+256</option>
                            <option data-countryCode="UA" value="380">+380</option>
                            <option data-countryCode="AE" value="971">+971</option>
                            <option data-countryCode="UY" value="598">+598</option>
                            <option data-countryCode="US" value="1">+1</option>
                            <option data-countryCode="UZ" value="7">+7</option>
                            <option data-countryCode="VU" value="678">+678</option>
                            <option data-countryCode="VA" value="379">+379</option>
                            <option data-countryCode="VE" value="58">+58</option>
                            <option data-countryCode="VN" value="84">+84</option>
                            <option data-countryCode="VG" value="84">+1284</option>
                            <option data-countryCode="VI" value="84">+1340</option>
                            <option data-countryCode="WF" value="681">+681</option>
                            <option data-countryCode="YE" value="969">+969</option>
                            <option data-countryCode="YE" value="967">+967</option>
                            <option data-countryCode="ZM" value="260">+260</option>
                            <option data-countryCode="ZW" value="263">+263</option>
                        </select>
                        <input type="text" class="form-control" name="mobile_number" id="mobile_number" placeholder="Phone Number" />
                        <span id="error_mobile_number"></span>
                    </div>
                    <div class="form-group">
                        <i class="fa fa-envelope-o"></i>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Your Email Address" />
                        <span id="error_email"></span>
                    </div>
                    <div class="form-group procedure-dropdown">
                        <i class="fa fa-calendar"></i>
                        <i class="fa fa-angle-down"></i>
                        <select class="form-control" id="topic" name="topic">
                            <option value="">When do you intend on doing this procedure?</option>
                            <option value="As soon as possible">As soon as possible</option>
                            <option value="Within a month">Within a month</option>
                            <option value="Within 3 months">Within 3 months</option>
                            <option value="Within 6 months">Within 6 months</option>
                            <option value="Just enquiring">Just enquiring</option>
                        </select>
                    </div>
                    <span id="error_procedure"></span>
                    <div class="form-group">
                        <i class="fa fa-envelope-o"></i>
                        <textarea class="form-control" placeholder="Message" id="message" name="message"></textarea>
                        <span id="error_message"></span>
                    </div>
                    <div class="catptcha-btn-group">
                        <div class="captcha-wrapper">
                            <form>
                                <?php
                                $random1 = rand('0', '9');
                                $random2 = rand('0', '9');
                                ?>
                                <span class="number"><?= $random1; ?></span>
                                <span class="operator">+</span>
                                <span class="number"><?= $random2; ?></span>
                                <span class="equal">=</span>
                                <input class="form-control" name="captchaVerify" id="captchaVerify" />

                                <input type="hidden" class="form-control" name="random1" id="random1" value="<?= $random1; ?>" />
                                <input type="hidden" class="form-control" name="random2" id="random2" value="<?= $random2; ?>" />
                            </form>
                        </div>
                        <button type="button" id="submitbtn" value="Contact Us Page" class="btn btn-primary">Submit <i class="fa fa-paper-plane-o "></i>
                    </div>
                    <div id="form_message" style="margin-top:20px; color:white;"></div>
                </form>
            </div>
        </div>
    </div>
    <div class="our-exp-bottom-container">
        <div class="container">
            <div class="clock-timing-list">
                <div class="clock-timing-item">
                    <div class="clock">
                        <div id="clock_uk"></div>
                    </div>
                    <h5>London</h5>
                    <span><?php echo esc_attr(get_option('londontitle')); ?></span>
                    <p><?php echo esc_attr(get_option('londonaddress')); ?></p>
                </div>
                <div class="clock-timing-item">
                    <div class="clock">
                        <div id="clock_istanbul"></div>
                    </div>
                    <h5>Istanbul</h5>
                    <span><?php echo esc_attr(get_option('instanbultitle')); ?></span>
                    <p><?php echo esc_attr(get_option('instanbuladdress')); ?></p>
                </div>
                <div class="clock-timing-item">
                    <div class="clock">
                        <div id="clock_tirana"></div>
                    </div>
                    <h5>Tirana</h5>
                    <span><?php echo esc_attr(get_option('tiranatitle')); ?></span>
                    <p><?php echo esc_attr(get_option('tiranaaddress')); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end get inttouch form-->

<!-- start embed map-->
<section class="embed-map">

    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.0503781639623!2d-0.09575828407432846!3d51.530635816824734!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761ca7536f641b%3A0x61f6d5173fc82c0b!2sBlueMagic%20Group-Hair%20Transplant%20Professionals!5e0!3m2!1sen!2sin!4v1611593468367!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3008.3897355593967!2d28.989839815415586!3d41.060472779295544!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cac7f6225e0f0f%3A0x8ddd7c0d444fabf!2sBlueMagic%20Group%20Hair%20Transplant%20Clinic%20-%20Istanbul%2C%20Turkey!5e0!3m2!1sen!2sin!4v1611747454889!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d28505.762361171648!2d19.80949714574926!3d41.32410740885609!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x135031c58529ba7d%3A0x40980b4ac9a3e04c!2sBlueMagic%20Group-Hair%20Transplant%20Professionals!5e0!3m2!1sen!2sin!4v1611747388176!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

</section>
<!-- end embed map-->


<!-- start free consultant section-->
<section class="free-consultant-wrapper">
    <div class="container">
        <div class="text-wrapper">
            <h2 class="white-color">Get your FREE CONSULTATION!</h2>
            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>
        </div>
        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
            <span>
                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                <span class="text">Get free consultation</span>
                <i class="fa fa-chevron-right"></i>
            </span>
        </a>
    </div>
</section>
<!--end free consultant section-->

<?php
get_footer();
