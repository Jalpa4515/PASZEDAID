<?php

/**
 * Template Name: Aboutpage-SPANISH
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>
<!-- start banner-->

<?php
$bgimgb = wp_get_attachment_url(get_field('banner'));
?>

<section id="about-us-banner" class="banner-wrapper common-banner-wrapper" style=" background-image: url(<?= $bgimgb; ?>);background-color: #f5e9de;background-repeat: no-repeat;background-position: center;background-size: cover;">

    <div class="container banner-outer-container">

        <div class="banner-info">

            <h2>

                <span class="blue display-inline"><?= get_field('title_in_blue'); ?></span>

                <span class="white-color display-inline"><?= get_field('title_in_black'); ?></span>

            </h2>

            <p><?= get_field('descriptions'); ?></p>

            <a href="<?= get_field('button_1_link') ? get_field('button_1_link') : "javascript:void(0)"; ?>" class="btn btn-primary-1"><?= get_field('button_1_title'); ?></a>

            <a href="<?= get_field('button_2_link') ? get_field('button_2_link') : "javascript:void(0)"; ?>" class="btn btn-secondary-white"><?= get_field('button_2_title'); ?></a>

        </div>
        <div class="banner-profile-image">
            <?php
            $bgimg = wp_get_attachment_url(get_field('banner_upper_image'));
            ?>
            <img src="<?php echo $bgimg; ?>" alt="Profile" />
        </div>

    </div>

</section>

<!-- end banner-->

<!-- start  breadcrumbs-->

<section class="breadcrumbs">

    <div class="container">

        <ul>

            <li><a href="<?= BASE_URL; ?>">Casa <i class="fa fa-angle-right"></i></a></li>

            <li class="active">Sobre nosotras</li>

        </ul>

    </div>

</section>

<!-- end breadcrumbs-->

<!-- start our exp section-->

<section class="our-exp-wrapper our-exp-wrapper-about">

    <div class="our-exp-bottom-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">Sobre nosotras</span>

                </div>

                <h2 class="text-center mb-35">

                    <span class="blue display-inline">OMS</span>

                    <span class="black display-inline">Nosotras somos</span>

                </h2>

                <div class="text-center">

                    <p class="mt-0"><?= get_field('who_we_are'); ?></p>

                </div>

            </div>

        </div>

    </div>

    <div class="our-exp-top-container">

        <div class="container">

            <div class="left-panel">
                <?php
                $what_we_do_image = wp_get_attachment_url(get_field('what_we_do_image'));
                ?>
                <span class="exp-banner">
                    <a href="#commonabout-modal" rel="modal:open">
                        <img src="<?php echo $what_we_do_image; ?>" alt="Our-Exp-Left" />
                    </a>
                </span>

                <span class="exp-logo">

                    <img src="<?php echo bloginfo('template_directory'); ?>/images/our-exp-left-logo.png" alt="Our-Exp-Logo" />

                </span>

            </div>


            <div class="modal" id="commonabout-modal">
                <div class="modal-overlay"></div>
                <div class="moaal-body-wrapper">
                    <p>
                        <iframe src="https://www.youtube.com/embed/7Qj2nVxQwuI" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </p>
                    <!-- <a href="#" rel="modal:close">Close</a> -->
                </div>
            </div>


            <div class="text-panel">

                <span class="section-title">Por qué nosotras</span>

                <h2>

                    <span class="blue display-inline">Por qué elegir
</span>

                    <span class="black display-inline">Grupo BlueMagic?
</span>

                </h2>

                <?= get_field('what_we_do_description'); ?>

            </div>

        </div>

    </div>


</section>

<!-- end our exp section-->

<!-- start bmg wrapper-->

<section class="our-exp-wrapper bmg-experience-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">Experiencia BMG
</span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline">Experimente la seguridad
</span>

                    <span class="black display-inline">por BlueMagic Group
</span>

                </h2>

                <div class="text-center">

                    <p><?= get_field('our_success_description'); ?></p>

                </div>



                <div class="text-center">

                    <blockquote class="blockquote-text"><?= get_field('our_success_tagline'); ?></blockquote>

                </div>

                <div class="video-wrapper">

                    <span class="video">
                        <?php
                        $our_success_image = wp_get_attachment_url(get_field('our_success_image'));
                        ?>
                        <img src="<?php echo $our_success_image; ?>" alt="Video-success" />

                    </span>

                    <p class="play-icon">

                        <a href="#bgm-modal" rel="modal:open">

                            <i class="fa fa-play"></i>

                        </a>

                    </p>

                    <div class="modal" id="bgm-modal">

                        <div class="modal-overlay"></div>

                        <div class="moaal-body-wrapper">

                            <p>

                                <iframe src="https://www.youtube.com/embed/BPsepDm94Aw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                            </p>

                            <!-- <a href="#" rel="modal:close">Close</a> -->

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- end bmg wrapper-->

<!-- start press and award tab-->

<section class="our-exp-wrapper press-award-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">Prensa y premios
</span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline">Completamente
 </span>

                    <span class="black display-inline">Autorizada</span>

                </h2>

                <div class="text-center">

                    <p><?= get_field('press_&_awards_descriptions'); ?></p>

                </div>

            </div>

        </div>

        <div class="tab-wrapper">

            <div class="container">

                <ul class="tab-title-wrapper">

                    <?php

                    $args = array(
                        'post_type' => 'press_awards',
                        'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $resultt = new WP_Query($args);
                    $i = 1;
                    while ($resultt->have_posts()) : $resultt->the_post();
                        $p_post = get_the_ID();
                        $imagep = wp_get_attachment_url(get_field('image', $p_post));
                        ?>
                        <li class="tab-title-item <?= $i == 1 ? "activelink" : ""; ?>">
                            <a href="javascript:void(0);" data-tag="<?= $p_post ?>">
                                <img src="<?php echo $imagep; ?>" alt="Bagde" />
                            </a>
                        </li>
                    <?php
                        $i++;
                    endwhile;
                    ?>

                </ul>

                <div class="tab-body-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'press_awards',
                        'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $resultt = new WP_Query($args);
                    $i = 1;
                    while ($resultt->have_posts()) : $resultt->the_post();
                        $p_post = get_the_ID();
                        ?>
                        <div class="list <?= $i == 1 ? "" : "hide"; ?>" id="<?= $p_post; ?>">

                            <p><?= get_field('descriptions', $p_post); ?></p>

                            <!-- <div class="text-center view-more-t-center">

                                <a href="<?= get_field('certificate_link', $p_post) ? get_field('certificate_link', $p_post) : "javascript:void(0)"; ?>" class="btn btn-primary btn-readmore">View Certificate <i class="fa fa-eye"></i></a>

                            </div> -->

                        </div>
                    <?php
                        $i++;
                    endwhile;
                    wp_reset_postdata();
                    ?>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- end press and award tab-->

<!-- start logos section-->

<section class="logos-wrapper">
    <div class="logos-list pl-0 pr-0" id="logo-list">
        <?php
        if (get_field('logo')) :
            while (has_sub_field('logo')) :
                $logoimage = wp_get_attachment_url(get_sub_field('image'));
                ?>
                <div>
                    <a href="javascript:void(0)">
                        <img src="<?php echo $logoimage; ?>" alt="Logo" />
                    </a>
                </div>
        <?php
            endwhile;
        endif;
        ?>
    </div>
</section>


<!-- end logos section-->

<!-- start our exp section-->

<section class="our-exp-wrapper our-clinic-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel">

                <span class="section-title white-color">Medios de comunicación
</span>

                <h2>

                    <span class="blue display-inline">Llegar a saber
 </span>

                    <span class="white-color display-inline">acerca de nuestra clínica
</span>

                </h2>

                <p class="white-color"><?= get_field('our_clinic_descriptions'); ?></p>
                <a style="margin-bottom: 15px;" href="<?= BASE_URL ?>our-media/" class="btn btn-primary btn-readmore">Saber más
 <i class="fa fa-long-arrow-right"></i></a>
            </div>

            <div class="left-panel">

                <div class="clinic-slider">

                    <?php
                    if (get_field('our_clinic_images')) :
                        while (has_sub_field('our_clinic_images')) :

                            $our_clinic_images = wp_get_attachment_url(get_sub_field('image'));
                            ?>

                            <div>

                                <div class="slider-info">

                                    <img src="<?php echo $our_clinic_images; ?>" alt="slider" />

                                </div>

                            </div>

                    <?php
                        endwhile;
                    endif;

                    ?>
                </div>

            </div>

        </div>

    </div>

</section>

<!-- end our exp section-->

<!-- start team slider-->

<section class="our-exp-wrapper team-slider-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">Nuestro equipo
</span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline">Satisfacer la
</span>

                    <span class="black display-inline"> profesionales!
</span>

                </h2>

                <div class="text-center">

                    <p><?= get_field('our_team_descriptions'); ?></p>

                </div>

            </div>

            <div class="team-memebr-info-wrapper">

                <ul class="tab-title-wrapper">

                    <?php
                    $i = 1;
                    $args = array(
                        'type'                     => 'our_team',
                        'child_of'                 => 0,
                        'parent'                   => '',
                        'orderby'                  => 'name',
                        'order'                    => 'DESC',
                        'hide_empty'               => 1,
                        'hierarchical'             => 1,
                        'pad_counts'               => false
                    );
                    $teamcats = get_categories($args);

                    foreach ($teamcats as $t_post) :

                        if ($t_post->slug == 'medical-doctor') {
                            ?>
                            <li class="tab-title-item <?= $i == 1 ? "activelink" : ""; ?>"><a href="javascript:void(0);" data-tag="medical<?= $i; ?>"><?= $t_post->name; ?> <i class="fa fa-stethoscope" aria-hidden="true"></i>
                                </a></li>

                            <!--  viken - 22/01/2021 work start -->

                        <?php
                                $i++;
                            } else if ($t_post->slug == 'medical-consultant') {
                                ?>
                            <li class="tab-title-item <?= $i == 1 ? "activelink" : ""; ?>"><a href="javascript:void(0);" data-tag="medical<?= $i; ?>"><?= $t_post->name; ?> <i class="fa fa-group" aria-hidden="true"></i>
                                </a></li>
                            <!--  viken - 22/01/2021 work end -->

                        <?php
                                $i++;
                            } else {
                                unset($t_post);
                                ?>
                        <?php
                            }
                            ?>
                    <?php
                    endforeach;
                    ?>

                </ul>

                <div class="tab-body-wrapper">

                    <?php
                    $i = 1;
                    $args = array(
                        'type'                     => 'our_team',
                        'child_of'                 => 0,
                        'parent'                   => '',
                        'orderby'                  => 'name',
                        'order'                    => 'DESC',
                        'hide_empty'               => 1,
                        'hierarchical'             => 1,
                        'pad_counts'               => false
                    );
                    $teamcats = get_categories($args);

                    foreach ($teamcats as $t_post) :
                        if ($t_post->slug == 'medical-doctor') {
                            ?>

                            <div class="team-member-slider list <?= $i == 1 ? "" : "hide"; ?>" id="medical<?= $i; ?>">

                                <?php
                                        $args = array(
                                            'cat' => $t_post->term_id,
                                            'post_type' => 'our_team',
                                            'posts_per_page' => -1 // this will retrive all the post that is published 
                                        );
                                        $result = new WP_Query($args);
                                        ?>

                                <?php while ($result->have_posts()) : $result->the_post(); ?>
                                    <?php $tid = get_the_ID(); ?>
                                    <div>

                                        <div class="slider-member-info">

                                            <span class="member-avtar">

                                                <?php $imagepv = wp_get_attachment_url(get_field('image', $tid)); ?>

                                                <img src="<?php echo $imagepv; ?>" alt="Team" />

                                            </span>

                                            <div class="member-info-wrapper">

                                                <div class="member-name">

                                                    <h4 class="black"><?= get_field('full_name', $tid); ?></h4>

                                                    <span><?= get_field('position', $tid); ?></span>

                                                </div>

                                                <div class="member-exp member-text">

                                                    <h5>Experiencia
 <span> <?= get_field('experiance', $tid); ?> Años</span></h5>

                                                </div>

                                                <div class="member-specialised member-text">

                                                    <h5>Especializada</h5>

                                                    <span><?= get_field('specialized', $tid); ?></span>

                                                </div>

                                                <div class="member-award  member-text">

                                                    <h5>Premios</h5>

                                                    <?= get_field('awards', $tid); ?>
                                                    <?php
                                                                if (get_field('certificate_link', $tid)) {
                                                                    ?>
                                                        <a target="_blank" href="<?= get_field('certificate_link', $tid) ? get_field('certificate_link', $tid) : "javascript:void(0)"; ?>">Ver Certificado
<i class="fa fa-angle-right"></i></a>
                                                    <?php
                                                                }
                                                                ?>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                <?php endwhile;
                                        wp_reset_postdata();
                                        ?>

                            </div>
                        <?php
                                $i++;
                            } else if ($t_post->slug == 'medical-consultant') {
                                ?>

                            <div class="team-member-slider list hide" id="medical<?= $i; ?>">

                                <div>
                                    <div class="slider-info team-consultant-wrapper">
                                        <?php
                                                if (get_field('medical_consultant')) :
                                                    $i = 1;

                                                    while (has_sub_field('medical_consultant')) :
                                                        if ($i <= 10) {
                                                            $imagev = wp_get_attachment_url(get_sub_field('image'));
                                                            ?>
                                                    <span class="consultant-item">
                                                        <img src="<?php echo $imagev; ?>" alt="Consultant" />
                                                    </span>
                                        <?php
                                                        }
                                                        $i++;
                                                    endwhile;

                                                endif;
                                                ?>
                                    </div>
                                </div>

                                <div>
                                    <div class="slider-info team-consultant-wrapper">
                                        <?php
                                                if (get_field('medical_consultant')) :
                                                    $i = 1;

                                                    while (has_sub_field('medical_consultant')) :
                                                        if ($i >= 11 && $i <= 20) {

                                                            $imagev = wp_get_attachment_url(get_sub_field('image'));
                                                            ?>

                                                    <span class="consultant-item">
                                                        <img src="<?php echo $imagev; ?>" alt="Consultant" />
                                                    </span>
                                        <?php
                                                        }
                                                        $i++;
                                                    endwhile;

                                                endif;
                                                ?>
                                    </div>
                                </div>

                                <div>
                                    <div class="slider-info team-consultant-wrapper">
                                        <?php
                                                if (get_field('medical_consultant')) :
                                                    $i = 1;

                                                    while (has_sub_field('medical_consultant')) :
                                                        if ($i >= 21) {

                                                            $imagev = wp_get_attachment_url(get_sub_field('image'));
                                                            ?>

                                                    <span class="consultant-item">
                                                        <img src="<?php echo $imagev; ?>" alt="Consultant" />
                                                    </span>

                                        <?php
                                                        }
                                                        $i++;
                                                    endwhile;

                                                endif;
                                                ?>
                                    </div>
                                </div>


                            </div>
                    <?php
                            $i++;
                        } else {
                            unset($t_post);
                        }
                    endforeach;
                    ?>
                </div>

            </div>

        </div>

    </div>

</section>

<!-- end team slider-->

<!-- start before after service slider-->

<section class="our-exp-wrapper testimonial-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">El cliente nos ama
</span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline">Paciente </span>

                    <span class="black display-inline">Testimonios
</span>

                </h2>

            </div>

        </div>

        <div class="rating-container">

            <div class="container">

                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/google.png" alt="Google"></a>

                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/trustpiolet.png" alt="Trust Piolet"></a>

                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/provenExport.png" alt="Proven Expert"></a>

            </div>

        </div>

        <div class="testimonial-slider-wrapper">

            <div class="container">

                <div class="testimonial-slider">

                    <?php
                    $args = array(
                        'post_type' => 'testimonials',
                        'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $resultt = new WP_Query($args);
                    while ($resultt->have_posts()) : $resultt->the_post();
                        $teid = get_the_ID();
                        ?>
                        <div>

                            <div class="slider-info">

                                <!--  viken - 22/01/2021 work start -->

                                <h5 class="display-inline"><?= get_field('testimonial_title', $teid); ?></h5>

                                <!--  viken - 22/01/2021 work end -->

                                <div class="slider-left">

                                    <?php $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>

                                    <img src="<?php echo $imagepv; ?>" alt="Testimonial" />

                                </div>

                                <?= get_field('descriptions', $teid); ?>

                                <h5 class="display-inline">- <?= get_field('full_name', $teid); ?></h5>

                                <!--  viken - 22/01/2021 work start -->

                                <h5 class="display-inline">- <?= get_field('country_name', $teid); ?></h5>

                                <span class="flag-icon">

                                    <?php $flagIcon = wp_get_attachment_url(get_field('flag_icon', $teid)); ?>

                                    <img src="<?php echo $flagIcon; ?>" />

                                </span>

                                <!--  viken - 22/01/2021 work end -->

                            </div>

                        </div>

                    <?php endwhile;
                    wp_reset_postdata();
                    ?>


                </div>

            </div>

        </div>

        <div class="text-center view-more-t-center">

            <a href="<?= BASE_URL ?>testimonial/" class="btn btn-primary btn-readmore">Ver más
<i class="fa fa-long-arrow-right"></i></a>

        </div>

    </div>

</section>

<!-- end before after service slider-->

<!-- start counnter section-->

<section class="counter-wrapper">

    <div class="container">

        <ul id="counter">

            <li>

                <span class="icon"><img src="<?php echo bloginfo('template_directory'); ?>/images/counnter-icon-1.png" alt="Exp" /></span>

                <div class="icon-info">

                    <strong class="counter-value" data-count="<?php echo esc_attr(get_option('yearofexp')); ?>">0</strong>

                    <span>Años de experiencia en Sterling
</span>

                </div>

            </li>

            <li>

                <span class="icon"><img src="<?php echo bloginfo('template_directory'); ?>/images/counnter-icon-2.png" alt="Exp" /></span>

                <div class="icon-info">

                    <strong class="counter-value" data-count="<?php echo esc_attr(get_option('hairtransplantation')); ?>">0</strong>

                    <span>Trasplantes exitosos
</span>

                </div>

            </li>

            <li>

                <span class="icon"><img src="<?php echo bloginfo('template_directory'); ?>/images/counnter-icon-3.png" alt="Exp" /></span>

                <div class="icon-info">

                    <strong class="counter-value" data-count="<?php echo esc_attr(get_option('daysupport')); ?>">0</strong>

                    <span>Días de soporte completo
</span>

                </div>

            </li>

        </ul>

    </div>

</section>

<!-- end counter section-->

<!-- start our news section-->

<section class="our-exp-wrapper our-news-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">Nuestras noticias
</span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline">Magia azul
</span>

                    <span class="black display-inline">Noticias
</span>

                </h2>

                <div class="text-center">

                    <p>¡Conozca más sobre el mundo del <b> procedimiento de trasplante de cabello </b> y BlueMagic Group para descubrir qué tratamiento sería el más adecuado para usted y su deseo de un cabello largo y grueso!
</p>

                </div>

                <div class="blog-list-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 3 // this will retrive all the post that is published 
                    );
                    $resulttc = new WP_Query($args);
                    if ($resulttc->have_posts()) {
                        while ($resulttc->have_posts()) : $resulttc->the_post();
                            $IDr = get_the_ID();
                            ?>
                            <div class="box-list-item">
                                <span class="blog-image">
                                    <img src="<?php echo get_the_post_thumbnail_url($IDr); ?>" alt="Blog" />
                                </span>
                                <span class="blog-date"><?php echo get_the_time('M d, Y', $IDr); ?></span>
                                <h4><?php echo get_the_title($IDr); ?></h4>
                                <a href="<?= get_the_permalink($IDr); ?>">Lee mas
 <i class="fa fa-long-arrow-right"></i></a>
                            </div>
                    <?php
                        endwhile;
                    }
                    ?>

                </div>

                <div class="text-center">

                    <a href="<?= BASE_URL . 'blog'; ?>" class="btn btn-primary btn-readmore">Ver más
 <i class="fa fa-long-arrow-right"></i></a>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- end our news section-->

<!--  viken - 22/01/2021 work start -->
<!-- start instagram section-->

<?php
// query the user media
$fields = "id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username";
$token = "your_long_lived_user_access_token";
$limit = 10;

$json_feed_url = "https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username&access_token=IGQVJYcThLNEgtVTRDRk5KY3ljTHd0UnYyQklfUXF6OTkyZAmtCWjdZAczF0Si1RX0FEakRFcS1FdUh5YjhiVUdCNm5EMDR4RmhrT3RVZAkFTSTZAzZA2paR040YUJGcFA3Szk5TmZAuRlNVM2p0aG9nc1RZAZAQZDZD&limit=10";
$json_feed = @file_get_contents($json_feed_url);
$contents = json_decode($json_feed, true, 512, JSON_BIGINT_AS_STRING);
?>
<section class="instagram-wrapper">
    <div class="container">
        <div class="topbar">
            <span class="insta-icon">
                <img src="<?php echo bloginfo('template_directory'); ?>/images/instagram-icon.png" alt="Instagram">
            </span>
            <h2 class="text-center">
                <span class="blue display-inline">@bluemagicgroupclinic</span>
            </h2>
        </div>
        <div class="instagram-item-wrapper">
            <?php
            foreach ($contents["data"] as $post) {

                $username = isset($post["username"]) ? $post["username"] : "";
                $caption = isset($post["caption"]) ? $post["caption"] : "";
                $media_url = isset($post["media_url"]) ? $post["media_url"] : "";
                $permalink = isset($post["permalink"]) ? $post["permalink"] : "";
                $media_type = isset($post["media_type"]) ? $post["media_type"] : "";
                $thumbnail_url = isset($post["thumbnail_url"]) ? $post["thumbnail_url"] : "";

                ?>
                <div class="instagram-item">
                    <?php
                        if ($media_type == "VIDEO") {
                            ?>
                        <video controls style='width:100%; display: block !important;' poster='<?php echo $thumbnail_url; ?>'>
                            <source src='<?php echo $media_url; ?>' type='video/mp4'>
                           Su navegador no soporta la etiqueta de vídeo.

                        </video>
                    <?php
                        } else {
                            ?>
                        <img src="<?php echo $media_url; ?>" alt="Instagram">
                    <?php
                        }
                        ?>

                </div>
            <?php } ?>
        </div>
        <div class="follow-us-wrapper">
            <a target="_blank" href="https://www.instagram.com/bluemagicgroupclinic/" class="btn btn-primary">
                Síganos

            </a>
        </div>
    </div>
</section>

<!-- end instagram section-->

<!-- start youtube section-->

<?php
//Get videos from channel by YouTube Data API
$API_key    = 'AIzaSyAqwtwoOwv1hjGX4zosfLoAdM4RYcG6V-s'; //my API key
$channelID  = 'UC6zsn59JBMobdHBY-u4mwhw'; //my channel ID
$maxResults = 3;

$video_list = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelID . '&maxResults=' . $maxResults . '&key=' . $API_key . ''));
?>


<section class="youtube-wrapper">
    <div class="container">
        <div class="topbar">
            <span class="insta-icon">
                <img src="<?php echo bloginfo('template_directory'); ?>/images/youtube-icon.png" alt="Youtube">
            </span>
            <h2 class="text-center">
                <span class="blue display-inline">Grupo BlueMagic
 </span>
                <span class="black display-inline">-Transplante de pelo
</span>
            </h2>
        </div>
        <div class="blog-list-wrapper">
            <?php
            foreach ($video_list->items as $item) {
                ?>
                <div class="box-list-item">
                    <span class="blog-image">
                        <a target="_blank" href="https://www.youtube.com/watch?v=<?php echo $item->id->videoId; ?>" style="background-image: url(<?= $item->snippet->thumbnails->high->url; ?>);">
                            <!--<img src="" alt="Blog" />-->
                        </a>
                    </span>
                    <h4><a style="font-size: 22px;line-height: 32px;font-weight: 500;color: #42474c;" target="_blank" href="https://www.youtube.com/watch?v=<?php echo $item->id->videoId; ?>"><?= $item->snippet->title; ?></a></h4>
                </div>
            <?php
            }
            ?>
        </div>
        <div class="follow-us-wrapper">
            <a target="_blank" href="https://www.youtube.com/channel/UC6zsn59JBMobdHBY-u4mwhw" class="btn btn-red">
                Suscribir
            </a>
        </div>
    </div>
</section>

<!-- end youtube section-->
<!--  viken - 22/01/2021 work end -->


<!-- start free consultant section-->

<section class="free-consultant-wrapper">

    <div class="container">

        <div class="text-wrapper">

            <h2 class="white-color">¡Obtén tu CONSULTA GRATIS!
</h2>

            <p class="white-color">¿Tienes curiosidad por saber cómo iría tu trasplante de cabello? Conéctese con nosotros hoy y permítanos ayudarlo a comprender todos y cada uno de los aspectos con la ayuda de una consulta gratuita. Y permítanos brindarle detalles completos con la ayuda de una consulta gratuita.
</p>

        </div>

        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">

            <span>

                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>

                <span class="text">Obtenga una consulta gratuita
</span>

                <i class="fa fa-chevron-right"></i>

            </span>

        </a>

    </div>

</section>

<!--end free consultant section-->

<?php
get_footer();
