<?php

/**
 * Template Name:  FAQ Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

<!-- start  breadcrumbs-->
<section class="breadcrumbs">
    <div class="container">
        <ul>
            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>
            <li><a href="javascript:void(0)">Patient Guide <i class="fa fa-angle-right"></i></a></li>
            <li class="active">FAQ's</li>
        </ul>
    </div>
</section>
<!-- end breadcrumbs-->
<!-- start press and award tab-->
<section class="our-exp-wrapper faq-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <h2>
                    <span class="blue display-inline">Frequently </span>
                    <span class="black display-inline">Asked Questions</span>
                </h2>
                <?php
                if (isset($_GET)) {
                    $b = $_GET['b'];
                } else {
                    $b = '';
                }
                ?>
                <div class="search-wrapper mb-0">
                    <form name="search" method="get">
                        <div class="form-group">
                            <input class="form-control" name="b" value="<?= $b; ?>" placeholder="Search Your Questions" />
                            <button class="btn btn-primary"> <i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="faq-inner-wrapper">

                <?php

                $args = array(
                    'type' => 'faq',
                    'orderby' => 'name',
                    'order'   => 'ASC',
                    'exclude' => array(1, 2, 3) // desire id
                );

                $teamcats = get_categories($args);

                $exi = 0;

                foreach ($teamcats as $t_post) : ?>
                    <?php
                        if ($b) {
                            $args = array(
                                'meta_query' => array(
                                    'relation' => 'OR',
                                    array(
                                        'key' => 'title',
                                        'value' => $b,
                                        'compare' => 'LIKE'
                                    ),
                                    array(
                                        'key' => 'descriptions',
                                        'value' => $b,
                                        'compare' => 'LIKE'
                                    )
                                ),
                                'cat' => $t_post->term_id,
                                'post_type' => 'faq',
                                'posts_per_page' => -1 // this will retrive all the post that is published 
                            );
                        } else {
                            $args = array(
                                'cat' => $t_post->term_id,
                                'post_type' => 'faq',
                                'posts_per_page' => -1 // this will retrive all the post that is published 
                            );
                        }
                        $result = new WP_Query($args);
                        ?>
                    <?php
                        if ($result->have_posts()) {
                            ?>
                        <div class="faq-item">
                            <h4 class="questions"><?= $t_post->name; ?><span class="toggle-icon"></span></h4>
                            <div class="faq-body">
                                <ul class="inner-accordion">
                                    <?php
                                            while ($result->have_posts()) : $result->the_post();
                                                $tid = get_the_ID(); ?>
                                        <li>
                                            <span class="inner-questions"><i class="fa fa-angle-right"></i><?= get_field('title', $tid); ?></span>

                                            <div class="inner-accordion-body">
                                                <p><?= get_field('descriptions', $tid); ?></p>
                                            </div>
                                        </li>

                                    <?php endwhile; ?>
                                </ul>
                            </div>
                        </div>
                    <?php
                            $exi = 1;
                        }
                        wp_reset_postdata();
                        ?>
                <?php
                endforeach;
                wp_reset_postdata();

                if ($exi == 0) {
                    ?>
                    <div class="">
                        <ul class="inner-accordion">
                            <p class="text-center">No FAQ found.</p>
                        </ul>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
</section>
<!-- end press and award tab-->
<!-- start free consultant section-->
<section class="free-consultant-wrapper">
    <div class="container">
        <div class="text-wrapper">
            <h2 class="white-color">Get your FREE CONSULTATION!</h2>
            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>
        </div>
        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
            <span>
                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                <span class="text">Get free consultation</span>
                <i class="fa fa-chevron-right"></i>
            </span>
        </a>
    </div>
</section>
<!--end free consultant section-->

<?php
get_footer();
