<?php

/**
 * Template Name: Our Services
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

<?php
$bgimg = wp_get_attachment_url(get_field('banner'));
$banner_upper_image = wp_get_attachment_url(get_field('banner_upper_image'));
?>

<!-- start banner-->

<section id="our-services-banner" class="banner-wrapper common-banner-wrapper" style="background: url(<?= $bgimg; ?>) no-repeat left top !important;">

    <div class="container banner-outer-container">

        <div class="banner-info">

            <h2>
                <span class="blue display-inline"><?= get_field('title_in_blue'); ?></span>
                <span class="black display-inline"><?= get_field('title_in_black'); ?></span>
            </h2>

            <?= get_field('descriptions'); ?>

            <a href="<?= get_field('button_1_link') ? get_field('button_1_link') : "javascript:void(0)"; ?>" class="btn btn-primary-1"><?= get_field('button_1_title'); ?></a>
            <a href="<?= get_field('button_2_link') ? get_field('button_2_link') : "javascript:void(0)"; ?>" class="btn btn-secondary"><?= get_field('button_2_title'); ?></a>

        </div>
        <div class="banner-profile-image">
            <img src="<?= $banner_upper_image; ?>" alt="Profile" />
        </div>

    </div>

</section>

<!-- end banner-->

<!-- start  breadcrumbs-->

<section class="breadcrumbs">

    <div class="container">

        <ul>

            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>

            <li class="active">Services</li>

        </ul>

    </div>

</section>

<!-- end breadcrumbs-->

<!-- start our exp section-->

<section class="hair-transplant-wrapper">
    <div class="container">
        <div class="transplant-wrapper">
            <div class="hair-transplant-left">
                <span><img src="<?php echo wp_get_attachment_url(get_field('transplantation_image')); ?>"></span>
            </div>
            <div class="hair-transplant-right">
                <h2>
                    <span class="blue display-inline"><?= get_field('sub_title_in_blue'); ?></span>
                    <span class="black display-inline"><?= get_field('sub_title_in_black'); ?></span>
                </h2>
                <p><?= get_field('transplantation_descriptions'); ?></p>
                <a href="<?= get_field('free_consultation_link'); ?>" class="btn btn-primary btn-readmore">Get Free Consultation <i class="fa fa-long-arrow-right"></i></a>
            </div>
        </div>
        <div class="blocquote-wrapper">
            <blockquote class="blockquote-text"><?= get_field('tagline'); ?></blockquote>
        </div>
    </div>
</section>

<!-- end our exp section-->

<!-- start bmg wrapper-->

<section class="our-exp-wrapper bmg-specialities-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines">Our Services</span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline">BlueMagic </span>

                    <span class="black display-inline">Specialities</span>

                </h2>

                <div class="text-center">

                    <p>BlueMagic Group seeks to provide everyone in London and throughout the UK struggv ling with hair loss with a luxurious experience from start to finish.</p>

                </div>

            </div>

            <div class="specialities-list-wrapper">

                <?php
                $args = array(
                    'post_type' => 'specialities',
                    'orderby' => 'ID',
                    'order' => 'ASC',
                    'posts_per_page' => -1 // this will retrive all the post that is published 
                );
                $resultt = new WP_Query($args);

                /* echo "<pre>";
                print_r($resultt); */

                $i = 1;
                while ($resultt->have_posts()) : $resultt->the_post();
                    $p_post = get_the_ID();
                    $imagep = wp_get_attachment_url(get_field('image', $p_post));
                    ?>
                    <div class="specialities-item">
                        <a href="javascript:void(0)">
                            <span class="item-img">
                                <img src="<?php echo $imagep; ?>" alt="<?= get_field('title', $p_post); ?>">
                            </span>

                            <h5><?= get_field('title', $p_post); ?></h5>
                        </a>
                    </div>
                <?php
                    $i++;
                endwhile;
                wp_reset_postdata();
                ?>

            </div>

        </div>

    </div>

</section>

<!-- end bmg wrapper-->

<!-- start fue services -->

<section class="our-exp-wrapper fue-services-wrapper">

    <div class="our-exp-top-container">

        <div class="container">

            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines white-color"><?= get_field('fue_title'); ?></span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline"><?= get_field('fue_title_in_blue'); ?> </span>

                    <span class="white-color display-inline"><?= get_field('fue_title_in_white'); ?></span>

                </h2>

                <div class="text-center">

                    <?= get_field('fue_descriptions'); ?>

                </div>

            </div>

        </div>

    </div>

</section>

<section class="fue-services-tab-wrapper">
    <div class="container">
        <ul class="tab-title-wrapper" id="onepage-menu">
            <?php
            $i = 1;
            if (get_field('fue_services_tabs')) :
                while (has_sub_field('fue_services_tabs')) :
                    if ($i == 1) {
                        $href = "#how-wrapper";
                    } elseif ($i == 2) {
                        $href = "#who-wrapper";
                    } elseif ($i == 3) {
                        $href = "#experience-wrapper";
                    } elseif ($i == 4) {
                        $href = "#after-fue-hair-transplant";
                    } elseif ($i == 5) {
                        $href = "#advantage-of-fue-wrapper";
                    } elseif ($i == 6) {
                        $href = "#faqs-wrapper";
                    }
                    ?>
                    <li class="tab-title-item <?= $i == 1 ? "activelink" : ""; ?>">
                        <a href="<?= $href ?>" data-tag="how<?= $i; ?>">
                            <?= get_sub_field('shortname'); ?>
                        </a>
                    </li>
            <?php
                    $i++;
                endwhile;
            endif;
            ?>

        </ul>
    </div>
</section>

<section id="fullpage-sections">
    <section class="how-container-body" id="how-wrapper">
        <div class="container">
            <div class="list">

                <div class="text-center">
                    <?php
                    $k = 1;
                    if (get_field('fue_services_tabs')) :
                        while (has_sub_field('fue_services_tabs')) :
                            if ($k == 1) {
                                ?>
                                <span class="section-title two-lines"><?= get_sub_field('shortname') ?></span>
                    <?php
                            }
                            $k++;
                        endwhile;
                    endif;
                    ?>
                </div>
                <?php
                $k = 1;
                if (get_field('fue_services_tabs')) :
                    while (has_sub_field('fue_services_tabs')) :
                        if ($k == 1) {
                            ?>

                            <h2 class="text-center">

                                <span class="blue display-inline"><?= get_sub_field('shortname') ?></span>

                                <span class="black display-inline"><?= get_sub_field('title') ?></span>

                            </h2>
                        <?php
                                }
                                ?>
                <?php
                        $k++;
                    endwhile;
                endif;
                ?>
                <div class="transplant-list-wrapper">
                    <ul class="transplant-list">
                        <?php
                        $k = 1;
                        if (get_field('fue_hair_transplants_steps')) :
                            while (has_sub_field('fue_hair_transplants_steps')) :
                                $logoimage = wp_get_attachment_url(get_sub_field('image'));
                                ?>
                                <li class="transplant-list-item">
                                    <span class="step-image">
                                        <img src="<?php echo $logoimage; ?>" alt="Step1" />
                                    </span>
                                    <div class="step-info">
                                        <h6>Step <?= $k; ?></h6>
                                        <h4><?= get_sub_field('title'); ?></h4>
                                        <?= get_sub_field('descriptions'); ?>
                                    </div>
                                </li>
                        <?php
                                $k++;
                            endwhile;
                        endif;
                        ?>
                    </ul>
                </div>

            </div>
        </div>
        <div class="blue-time-wrapper">
            <div class="container">

                <span class="time-img">
                    <img src="<?php echo bloginfo('template_directory'); ?>/images/Our-Services/How-Long-Does.png" alt="How long does" />
                </span>
                <h4><span><?= get_field('time_title_in_blue'); ?></span> <?= get_field('time_title_in_black'); ?></h4>
                <p><?= get_field('time_descriptions'); ?></p>

            </div>
        </div>

    </section>
    <!-- end fue services -->
    <!-- start our exp section-->
    <section class="our-exp-wrapper right-candidate-wrapper" id="who-wrapper">

        <div class="our-exp-top-container">

            <div class="container">

                <div class="text-panel">

                    <span class="section-title">Who?</span>

                    <h2>

                        <span class="blue display-inline"><?= get_field('who_-_title_in_blue'); ?> </span>

                        <span class="black display-inline"><?= get_field('who_-_title_in_black'); ?></span>

                    </h2>

                    <p><?= get_field('who_-_descriptions'); ?></p>

                    <a href="<?= get_field('who_-_button_link'); ?>" class="btn btn-primary btn-readmore">Get Free Consultation<i class="fa fa-long-arrow-right"></i></a>
                </div>

                <div class="left-panel">

                    <div class="factor-wrapper">
                        <h4><?= get_field('other_factor_title'); ?></h4>
                        <ul>
                            <?php
                            $i = 1;
                            if (get_field('other_factor_process')) :
                                while (has_sub_field('other_factor_process')) :
                                    ?>
                                    <li>
                                        <span class="icon"></span>
                                        <span><?= get_sub_field('title'); ?></span>
                                    </li>
                            <?php
                                    $i++;
                                endwhile;
                            endif;
                            ?>
                        </ul>
                    </div>

                </div>

            </div>

        </div>

    </section>
    <!-- end our exp section-->
    <!-- start FUE experience-->
    <section class="our-exp-wrapper fue-experience-video-outer-wrapper" id="experience-wrapper">

        <div class="our-exp-top-container">

            <div class="container">

                <div class="text-panel w-100">

                    <div class="text-center">

                        <span class="section-title two-lines">Our Media</span>

                    </div>

                    <h2 class="text-center">

                        <span class="blue display-inline">FUE </span>

                        <span class="black display-inline">Experience</span>

                    </h2>

                </div>

            </div>

        </div>

        <div class="fue-experience-video-wrapper">
            <div class="container">
                <div class="tab-body-wrapper">
                    <?php
                    $i = 1;
                    if (get_field('fuw_experience')) :
                        while (has_sub_field('fuw_experience')) :
                            ?>
                            <div class="list <?= $i == 1 ? "" : "hide"; ?>" id="after-before-<?= $i; ?>">

                                <div class="video-wrapper">

                                    <span class="video">

                                        <img src="<?php echo wp_get_attachment_url(get_sub_field('image')); ?>" alt="Video-success" />

                                    </span>

                                    <span class="play-icon">

                                        <a href="#after-before-modal<?= $i ?>" rel="modal:open">

                                            <i class="fa fa-play"></i>

                                        </a>

                                    </span>

                                </div>

                            </div>
                    <?php
                            $i++;
                        endwhile;
                    endif;
                    ?>

                    <?php
                    $i = 1;
                    if (get_field('fuw_experience')) :
                        while (has_sub_field('fuw_experience')) :
                            ?>
                            <div class="modal" id="after-before-modal<?= $i ?>">

                                <div class="modal-overlay"></div>

                                <div class="moaal-body-wrapper">

                                    <p>

                                        <iframe src="<?= get_sub_field('video'); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                                    </p>

                                    <!-- <a href="#" rel="modal:close">Close</a> -->

                                </div>

                            </div>
                    <?php
                            $i++;
                        endwhile;
                    endif;
                    ?>

                </div>
            </div>
            <ul class="tab-title-wrapper">
                <?php
                $i = 1;
                if (get_field('fuw_experience')) :
                    while (has_sub_field('fuw_experience')) :
                        ?>
                        <li class="tab-title-item-video">
                            <a href="javascript:void(0);" data-tag="after-before-<?= $i; ?>">
                                <img src="<?php echo wp_get_attachment_url(get_sub_field('image')); ?>" alt="Video1" />
                            </a>
                        </li>
                <?php
                        $i++;
                    endwhile;
                endif;
                ?>
            </ul>
        </div>

    </section>
    <!-- end FUE experience-->
    <!-- start our exp section-->
    <section class="our-exp-wrapper after-treatment-wrapper" id="after-fue-hair-transplant">
        <div class="our-exp-top-container">
            <div class="container">
                <div class="text-panel w-100 p-0">
                    <span class="section-title default-title-spacing">After Treatment</span>
                    <h2>
                        <span class="blue display-inline">After </span>
                        <span class="black display-inline">FUE Hair Transplant</span>
                    </h2>
                    <ol class="treatment-list">
                        <?php
                        $i = 1;
                        if (get_field('after_treatment_steps')) :
                            while (has_sub_field('after_treatment_steps')) :
                                ?>
                                <li>
                                    <span class="number">
                                        <?php
                                                if ($i > 9) {
                                                    echo $i;
                                                } else {
                                                    echo '0' . $i;
                                                }
                                                ?>
                                    </span>
                                    <?= get_sub_field('descriptions'); ?>
                                </li>
                        <?php
                                $i++;
                            endwhile;
                        endif;
                        ?>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <!-- end our exp section-->
    <!-- start after exp section-->
    <section class="advantage-fue-wrapper" id="advantage-of-fue-wrapper">
        <span class="advantage-image">
            <img src="<?php echo wp_get_attachment_url(get_field('advantages_of_fue_image')); ?>" alt="Advantage" />
        </span>
        <div class="container">
            <div class="factor-wrapper">
                <h4><span class="blue"><?= get_field('advantages_of_fue_title_in_blue'); ?></span> <?= get_field('advantages_of_fue_title_in_black'); ?></h4>
                <ul>
                    <?php
                    $i = 1;
                    if (get_field('advantages_steps')) :
                        while (has_sub_field('advantages_steps')) :
                            ?>
                            <li>
                                <span class="icon"></span>
                                <?= get_sub_field('descriptions'); ?>
                            </li>
                    <?php
                            $i++;
                        endwhile;
                    endif;
                    ?>

                </ul>
            </div>
        </div>
    </section>
    <!-- end after exp section-->
    <!-- start faq-->
    <section class="our-exp-wrapper faq-wrapper" id="faqs-wrapper">
        <div class="our-exp-top-container">
            <div class="container">
                <div class="text-panel w-100">
                    <div class="text-center">
                        <span class="section-title two-lines">FUE Hair Transplant</span>
                    </div>
                    <h2 class="text-center">
                        <span class="blue display-inline">Frequently </span>
                        <span class="black display-inline">Asked Questions</span>
                    </h2>
                </div>
                <div class="faq-inner-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'faq',
                        'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $result = new WP_Query($args);
                    while ($result->have_posts()) : $result->the_post() ?>
                        <?php $tid = get_the_ID(); ?>
                        <div class="faq-item">
                            <h4 class="questions"><?= get_field('title', $tid); ?><span class="toggle-icon"></span></h4>
                            <div class="faq-body">
                                <?= get_field('descriptions', $tid); ?>
                            </div>
                        </div>
                    <?php
                    endwhile;
                    wp_reset_postdata();
                    ?>

                </div>
            </div>
        </div>
    </section>
    <!-- end faq-->
</section>


<!-- start free consultant section-->

<section class="free-consultant-wrapper">

    <div class="container">

        <div class="text-wrapper">

        <h2 class="white-color">Get your FREE CONSULTATION!</h2>

            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>

        </div>

        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">

            <span>

                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>

                <span class="text">Get free consultation</span>

                <i class="fa fa-chevron-right"></i>

            </span>

        </a>

    </div>

</section>

<!--end free consultant section-->

<?php
get_footer();
