<?php

/**
 * Template Name: Our book page - SPANISH
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>
<!-- start banner-->


<!-- start  breadcrumbs-->

<section class="breadcrumbs">
    <div class="container">
        <ul>
            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>
            <li class="active">Our Book</li>
        </ul>
    </div>
</section>

<!-- end breadcrumbs-->

<!-- start our exp section-->
<section class="our-exp-wrapper things-to-know-about">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel">
                <h2>
                    <span class="blue"><?= get_field('title_in_blue'); ?></span>
                    <span class="black"><?= get_field('title_in_black'); ?></span>
                </h2>
                <?= get_field('descriptions'); ?>
                <div class="amazon-partner-link-wrapper">
                    <a href="https://www.amazon.com/NEED-KNOW-ABOUT-HAIR-TRANSPLANT-dp-1527267547/dp/1527267547/ref=mt_other?_encoding=UTF8&me=&qid=" target="_blank"><img src="<?php echo bloginfo('template_directory'); ?>/images/amazon1.png" alt="Amazon"></a>
                    <a href="https://www.amazon.com/NEED-KNOW-ABOUT-HAIR-TRANSPLANT-ebook-dp-B08D2GPMHF/dp/B08D2GPMHF/ref=mt_other?_encoding=UTF8&me=&qid=" target="_blank"><img src="<?php echo bloginfo('template_directory'); ?>/images/amazon2.png" alt="Amazon"></a>
                </div>
            </div>
            <div class="left-panel">
                <img src="<?php echo wp_get_attachment_url(get_field('image')); ?>" alt="Our Book" />
            </div>
        </div>
    </div>
</section>
<!-- end our exp section-->
<!--  start three box section-->
<section class="three-box-section">
    <div class="container">
        <div class="three-box-wrapper">
            <?php
            if (get_field('second_section')) :
                while (has_sub_field('second_section')) :
                    $logoimage = wp_get_attachment_url(get_sub_field('image'));
                    ?>

                    <div class="three-box-item">
                        <div class="box-info">
                            <a href="javascript:void(0)"><img src="<?php echo $logoimage; ?>" alt="Book" /></a>
                        </div>
                        <!--<div class="hover-info">-->
                        <!--<h6><?= get_sub_field('title'); ?></h6>-->
                        <!--<?= get_sub_field('descriptions'); ?>-->
                        <!--</div>-->
                    </div>

            <?php
                endwhile;
            endif;
            ?>
        </div>
    </div>
</section>
<!-- end three box section-->
<!-- end specialities service slider-->
<section class="our-exp-wrapper content-book-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title white-color two-lines">Content</span>
                </div>
                <div class="text-center">
                    <h2>
                        <span class="blue display-inline"><?= get_field('content_title_in_blue'); ?></span>
                        <span class="black display-inline white-color"><?= get_field('content_title_in_white'); ?></span>
                    </h2>
                </div>
                <div class="factor-wrapper p-0">
                    <ul>
                        <?php
                        if (get_field('content')) :
                            while (has_sub_field('content')) :
                                $logoimage = wp_get_attachment_url(get_sub_field('image'));
                                ?>
                                <li>
                                    <span class="icon"></span>
                                    <span><?= get_sub_field('title'); ?></span>
                                </li>
                        <?php
                            endwhile;
                        endif;
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- start get inttouch form-->
<section class="our-exp-wrapper author-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100 pl-0">
                <span class="section-title">Writer</span>
                <h2>
                    <span class="blue display-inline">About </span>
                    <span class="black display-inline">The Author</span>
                </h2>
            </div>
            <div class="author-slider-wrapper">
                <div class="author-slider">
                    <?php
                    if (get_field('author')) :
                        while (has_sub_field('author')) :
                            $logoimage = wp_get_attachment_url(get_sub_field('image'));
                            ?>
                            <div>
                                <div class="author-info">
                                    <span class="author-img">
                                        <img src="<?php echo $logoimage; ?>" alt="Author" />
                                    </span>
                                    <div class="author-info-text">
                                        <h5 class="blue"><?= get_sub_field('title'); ?></h5>
                                        <?= get_sub_field('descriptions'); ?>
                                        <ul class="social-media-list">
                                            <li>
                                                <a href="<?= get_sub_field('facebook'); ?>" target="_blank">
                                                    <i class="fa fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= get_sub_field('linkedin'); ?>" target="_blank">
                                                    <i class="fa fa-linkedin"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?= get_sub_field('instagram'); ?>" target="_blank">
                                                    <i class="fa fa-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                    <?php
                        endwhile;
                    endif;
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end get inttouch form-->
<!-- start faq-->
<section class="our-exp-wrapper faq-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Our Support</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Frequently </span>
                    <span class="black display-inline">Asked Questions</span>
                </h2>
            </div>
            <div class="faq-inner-wrapper">
                <?php
                $args = array(
                    'cat' => 18,
                    'post_type' => 'faq',
                    'posts_per_page' => 8 // this will retrive all the post that is published 
                );
                $result = new WP_Query($args);
                while ($result->have_posts()) : $result->the_post() ?>
                    <?php $tid = get_the_ID(); ?>
                    <div class="faq-item">
                        <h4 class="questions"><?= get_field('title', $tid); ?><span class="toggle-icon"></span></h4>
                        <div class="faq-body">
                            <p><?= get_field('descriptions', $tid); ?></p>
                        </div>
                    </div>
                <?php
                endwhile;
                wp_reset_postdata();
                 $argss = array(
                                        'cat' => $t_post->term_id,
                                        'post_type' => 'faq',
                                        'posts_per_page' => -1 // this will retrive all the post that is published 
                                    );
                                    $results = new WP_Query($argss);
                if (count($results->posts) > 8) {
                    ?>
                    <div class="text-center view-more-t-center">
                        <a href="<?php echo BASE_URL ?>faq/" class="btn btn-primary btn-readmore">Know More <i class="fa fa-long-arrow-right"></i></a>
                    </div>
                <?php
                }
                ?>

            </div>
        </div>
    </div>
</section>
<!-- end faq-->
<!-- start free consultant section-->
<section class="free-consultant-wrapper">
    <div class="container">
        <div class="text-wrapper">
            <h2 class="white-color">Get your FREE CONSULTATION!</h2>
            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>
        </div>
        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
            <span>
                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                <span class="text">Get free consultation</span>
                <i class="fa fa-chevron-right"></i>
            </span>
        </a>
    </div>
</section>
<!--end free consultant section-->
<div class="modal" id="offer-modal">
    <div class="modal-overlay"></div>
    <div class="modal-body-wrapper">
        <div class="modal-body-left">
            <img src="<?php echo bloginfo('template_directory'); ?>/images/6_9_banner.png" alt="6_9_Book">
        </div>
        <div class="modal-body-right">
            <h2>
                <span class="blue display-inline">70%</span>
                <span class="black display-inline">Discount</span>
            </h2>
            <h3>Limited Time Offer <span><i class="fa fa-clock-o"></i>8:25</span></h3>
            <form name="personal-info-form" method="POST">
                <div class="form-group">
                    <i class="fa fa-user"></i>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Full Name *" />
                    <span id="error_name"></span>
                </div>
                <div class="form-group">
                    <i class="fa fa-envelope"></i>
                    <input type="text" id="email" name="email" class="form-control" placeholder="Email Address *" />
                    <span id="error_email"></span>
                </div>
                <div class="form-group">
                    <i class="fa fa-phone"></i>
                    <input type="text" class="form-control" name="mobile_number" id="mobile_number" placeholder="Phone Number *" />
                    <span id="error_mobile_number"></span>
                </div>
                <button class="btn btn-primary" type="button" id="submitbtn2">Get Discount</button>
            </form>
            <div id="form_message" style="margin-top:20px; color:black;"></div>
        </div>
        <!-- <a href="#" rel="modal:close">Close</a> -->
    </div>
</div>
<?php
get_footer();
