<!DOCTYPE html>
<html>

<head>
    <title>BlueMagic-Thank-you</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link rel="stylesheet" href="<?php echo bloginfo('template_directory'); ?>/css/jClocksGMT.css">
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_directory'); ?>/css/style.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo bloginfo('template_directory'); ?>/css/responsive.css" />
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Global site tag (gtag.js) - Google Ads: 405681226 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-405681226"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-405681226');
    </script>
    <!-- Event snippet for Sign-up conversion page -->
    <script>
      gtag('event', 'conversion', {'send_to': 'AW-405681226/N24LCL3urvsBEMrouMEB'});
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-108450792-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-108450792-1');
    </script>
</head>

<body class="blue-magic-info-text">
    <!--start header-->
    <header>
        <div class="header-topbar">
            <div class="container">
                <div class="d-flex-container">
                    <div class="logo">
                        <a href="<?= BASE_URL; ?>">
                            <img src="<?php echo bloginfo('template_directory'); ?>/images/logo.png" alt="Blue Magic" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--end header-->
    <!-- start thankyou wrapper-->
    <section class="info-text-wrapper">
        <div class="container">
            <span class="thank-you-image">
                <img src="<?php echo bloginfo('template_directory'); ?>/images/thank-you.png" alt="Thank You" />
            </span>
            <h3>Your message has been sent </h3>
            <p>We have received your message. We’ll reach out immediately.</p>
            <a href="<?= BASE_URL; ?>" class="btn btn-primary">Go Home</a>
        </div>
    </section>
    <!-- end thank you wrapper-->
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://use.fontawesome.com/ac31ebd8bf.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="<?php echo bloginfo('template_directory'); ?>/js/custom.js"></script>
    
</body>

</html>