<?php

/**
 * Template Name: Testimonialpage
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

<div class="testimonial-wrapper-body">

    <!-- start  breadcrumbs-->
    <section class="breadcrumbs">
        <div class="container">
            <ul>
                <li><a href="javascript:void(0)">Home <i class="fa fa-angle-right"></i></a></li>
                <li class="active">Patient Testimonials</li>
            </ul>
        </div>
    </section>
    <!-- end breadcrumbs-->
    <section class="testimonial-outer-wrapper testimonial-wrapper our-exp-wrapper final-results-wrapper">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Client Love Us</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Patient </span>
                    <span class="black display-inline">Testimonials</span>
                </h2>
            </div>

            <div class="rating-container">
                <div class="container">
                    <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/google.png" alt="Google"></a>
                    <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/trustpiolet.png" alt="Trust Piolet"></a>
                    <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/provenExport.png" alt="Proven Expert"></a>
                </div>
            </div>

            <div class="final-results-wrapper">

                <div class="team-memebr-info-wrapper">
                    <ul class="tab-title-wrapper">
                        <li class="tab-title-item activelink"><a href="javascript:void(0);" data-tag="reviews-testimonial">Reviews</i></a></li>
                        <li class="tab-title-item"><a href="javascript:void(0);" data-tag="video-testimonial">Video Testimonials </a></li>
                    </ul>

                    <div class="tab-body-wrapper">

                        <div class="team-member-results list" id="reviews-testimonial">
                            <div class="container">
                                <div class="testimonial-slider-wrapper">
                                    <div class="testimonial-slider-reviews">

                                        <?php
                                        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                                        $args = array(
                                            'post_type' => 'testimonials',
                                            'posts_per_page' => -1, // this will retrive all the post that is published 
                                            'paged' => $paged,
                                            'posts_per_page' => 4 // this will retrive all the post that is published 
                                        );
                                        $resultt = new WP_Query($args);

                                        while ($resultt->have_posts()) : $resultt->the_post();
                                            $teid = get_the_ID();
                                            ?>
                                            <div class="slider-info">
                                                <div class="slider-left">
                                                    <?php $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>
                                                    <img src="<?php echo $imagepv; ?>" />
                                                </div>
                                                <h5 class="display-inline"><?= get_field('testimonial_title', $teid); ?></h5>
                                                <p><?= get_field('descriptions', $teid); ?></p>
                                                <div class="blockquote-bg-wrapper">
                                                    <h5 class="display-inline">- <?= get_field('full_name', $teid); ?></h5>
                                                    <h5 class="display-inline">- <?= get_field('country_name', $teid); ?></h5>
                                                    <span class="flag-icon">
                                                        <?php $flagIcon = wp_get_attachment_url(get_field('flag_icon', $teid)); ?>
                                                        <img src="<?php echo $flagIcon; ?>" />
                                                    </span>
                                                </div>
                                            </div>

                                        <?php endwhile;
                                        wp_reset_postdata();
                                        ?>
                                    </div>
                                    <?php
                                    if (function_exists("pagination")) {
                                        pagination($resultt->max_num_pages);
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div class="team-member-results video-testimonial-list list hide" id="video-testimonial">

                            <?php
                            $args = array(
                                'post_type' => 'video-testimonial',
                                'posts_per_page' => -1 // this will retrive all the post that is published 
                            );
                            $resultt = new WP_Query($args);
                            $i = 1;
                            while ($resultt->have_posts()) : $resultt->the_post();
                                $teid = get_the_ID();
                                $video_link = get_field('video');
                                $id = substr($video_link, strrpos($video_link, '/') + 1);
                                $logoimage = "https://img.youtube.com/vi/" . $id . "/0.jpg";
                                ?>
                                <div class="result-item">
                                    <a href="#video-result-modal<?= $i; ?>" rel="modal:open" style="background-image: url(<?= $logoimage; ?>);">

                                        <i class="play-icon-img">
                                            <img src="<?php echo bloginfo('template_directory'); ?>/images/play-icon.png" alt="play-icon">
                                        </i>
                                    </a>
                                </div>
                            <?php
                                $i++;
                            endwhile;
                            ?>

                        </div>

                        <?php
                        $args = array(
                            'post_type' => 'video-testimonial',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultt = new WP_Query($args);
                        $i = 1;
                        while ($resultt->have_posts()) : $resultt->the_post();
                            $teid = get_the_ID();
                            $video_link = get_field('video');
                            $id = substr($video_link, strrpos($video_link, '/') + 1);
                            $logoimage = "https://img.youtube.com/vi/" . $id . "/0.jpg";
                            ?>
                            <div class="modal" id="video-result-modal<?= $i; ?>">
                                <div class="modal-overlay"></div>
                                <div class="moaal-body-wrapper">
                                    <p>
                                        <iframe src="<?= $video_link; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                    </p>
                                    <!-- <a href="#" rel="modal:close">Close</a> -->
                                </div>
                            </div>
                        <?php
                            $i++;
                        endwhile;
                        ?>


                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- start free consultant section-->
    <section class="free-consultant-wrapper">
        <div class="container">
            <div class="text-wrapper">
                <h2 class="white-color">Get your FREE CONSULTATION!</h2>
                <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>
            </div>
            <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
                <span>
                    <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                    <span class="text">Get free consultation</span>
                    <i class="fa fa-chevron-right"></i>
                </span>
            </a>
        </div>
    </section>

</div>


<?php
get_footer();
