<?php

/**
 * Template Name: Service Detail
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

<?php
$bgimg = wp_get_attachment_url(get_field('banner'));
$banner_upper_image = wp_get_attachment_url(get_field('banner_upper_image'));
?>

<!-- start banner-->

<section id="our-services-banner" class="banner-wrapper common-banner-wrapper" style="background-image: url(<?= $bgimg; ?>);background-repeat: no-repeat ;background-position: center ;background-size: cover;">

    <div class="container banner-outer-container">

        <div class="banner-info">

            <h2>
                <span class="blue display-inline"><?= get_field('title_in_blue'); ?></span>
                <span class="display-inline white-color"><?= get_field('title_in_black'); ?></span>
            </h2>

            <?= get_field('descriptions'); ?>

            <a href="<?= get_field('button_1_link') ? get_field('button_1_link') : "javascript:void(0)"; ?>" class="btn btn-primary-1"><?= get_field('button_1_title'); ?></a>
            <a href="<?= get_field('button_2_link') ? get_field('button_2_link') : "javascript:void(0)"; ?>" class="btn btn-secondary-white"><?= get_field('button_2_title'); ?></a>

        </div>
        <div class="banner-profile-image">
            <img src="<?= $banner_upper_image; ?>" alt="Profile" />
        </div>

    </div>

</section>

<!-- end banner-->

<!-- start  breadcrumbs-->
<?php

$slug = get_post_field('post_name', get_post());
?>
<section class="breadcrumbs">

    <div class="container">

        <ul>

            <li><a href="javascript:void(0)">Home <i class="fa fa-angle-right"></i></a></li>

            <li class="active">Services</li>

        </ul>
        <?php
        if ($slug == 'manual-hair-transplant') {
            ?>
            <ul class="badgedesktop">
                <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/02/exclusive-badge.png">
            </ul>

        <?php } ?>

    </div>

</section>

<!-- end breadcrumbs-->

<?php
if ($slug == 'hair-transplant') {
    ?>

    <!-- start our exp section-->

    <section class="hair-transplant-wrapper">
        <div class="container">
            <div class="transplant-wrapper">
                <div class="hair-transplant-left">
                    <span><img src="<?php echo wp_get_attachment_url(get_field('transplantation_image')); ?>"></span>
                </div>
                <div class="hair-transplant-right">
                    <h2>
                        <span class="blue display-inline"><?= get_field('sub_title_in_blue'); ?></span>
                        <span class="black display-inline"><?= get_field('sub_title_in_black'); ?></span>
                    </h2>
                    <p><?= get_field('transplantation_descriptions'); ?></p>
                    <a href="<?= get_field('free_consultation_link'); ?>" class="btn btn-primary btn-readmore">Get Free Consultation <i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
            <div class="blocquote-wrapper">
                <blockquote class="blockquote-text"><?= get_field('tagline'); ?></blockquote>
            </div>
        </div>
    </section>

    <!-- end our exp section-->

    <!-- start bmg wrapper-->

    <section class="our-exp-wrapper bmg-specialities-wrapper">

        <div class="our-exp-top-container">

            <div class="container">

                <div class="text-panel w-100">

                    <div class="text-center">

                        <span class="section-title two-lines">Our Services</span>

                    </div>

                    <h2 class="text-center">

                        <span class="blue display-inline">BlueMagic </span>

                        <span class="black display-inline">Specialities</span>

                    </h2>

                    <div class="text-center">

                        <p>We specialize in carrying hair transplants of the highest quality, along with a magical and luxurious experience that you’ll cherish for lifetime! </p>

                    </div>

                </div>

                <div class="specialities-list-wrapper">

                    <?php
                        $args = array(
                            'post_type' => 'specialities',
                            'orderby' => 'ID',
                            'order' => 'ASC',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultt = new WP_Query($args);

                        /* echo "<pre>";
                print_r($resultt); */

                        $i = 1;
                        while ($resultt->have_posts()) : $resultt->the_post();
                            $p_post = get_the_ID();
                            $imagep = wp_get_attachment_url(get_field('image', $p_post));
                            ?>
                        <div class="specialities-item">
                            <a href="<?= get_field('page_link', $p_post); ?>">
                                <span class="item-img">
                                    <img src="<?php echo $imagep; ?>" alt="<?= get_field('title', $p_post); ?>">
                                </span>

                                <h5><?= get_field('title', $p_post); ?></h5>
                            </a>
                        </div>
                    <?php
                            $i++;
                        endwhile;
                        wp_reset_postdata();
                        ?>

                </div>

            </div>

        </div>

    </section>

    <!-- end bmg wrapper-->
<?php
    $bgcolor = '';
} else {
    $bgcolor = 'style="background-color:#f7f7f7 !important;"';
}
?>

<!-- start fue services -->

<section class="our-exp-wrapper fue-services-wrapper" <?= $bgcolor; ?>>

    <div class="our-exp-top-container">

        <div class="container">
            <?php
            if ($slug == 'manual-hair-transplant') {
                ?>
                <div class="text-center badgemobile">
                    <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/02/exclusive-badge.png" width="25%" class="text-center" style="">
                </div>
            <?php
            }
            ?>
            <div class="text-panel w-100">

                <div class="text-center">

                    <span class="section-title two-lines <?= $bgcolor == '' ? 'white-color' : 'black'; ?>"><?= get_field('fue_title'); ?></span>

                </div>

                <h2 class="text-center">

                    <span class="blue display-inline"><?= get_field('fue_title_in_blue'); ?> </span>

                    <span class=" <?= $bgcolor == '' ? 'white-color' : 'black'; ?> display-inline"><?= get_field('fue_title_in_white'); ?></span>

                </h2>

                <div class="text-center">

                    <?= get_field('fue_descriptions'); ?>

                </div>

            </div>

        </div>

    </div>

</section>

<section class="fue-services-tab-wrapper">
    <div class="container">
        <ul class="tab-title-wrapper" id="onepage-menu">
            <?php
            $i = 1;
            if (get_field('fue_services_tabs')) :
                while (has_sub_field('fue_services_tabs')) :
                    $style = "";
                    if ($i == 1) {
                        $href = "#how-wrapper";
                    } elseif ($i == 2) {
                        $href = "#who-wrapper";
                    } elseif ($i == 3) {
                        $href = "#experience-wrapper";

                        // if ($slug == 'prp-hair-treatment') {
                        //     $style = "style='display:none;'";
                        // }
                        // if ($slug == 'eyebrow-transplantation') {
                        //     $style = "style='display:none;'";
                        // }
                    } elseif ($i == 4) {
                        $href = "#after-fue-hair-transplant";
                    } elseif ($i == 5) {
                        $href = "#advantage-of-fue-wrapper";
                    } elseif ($i == 6) {
                        $href = "#faqs-wrapper";
                    }

                    ?>
                    <li <?= $style; ?> class="tab-title-item <?= $i == 1 ? "activelink" : ""; ?>">
                        <a href="<?= $href ?>" data-tag="how<?= $i; ?>">
                            <?= get_sub_field('shortname'); ?>
                        </a>
                    </li>
            <?php
                    $i++;
                endwhile;
            endif;
            ?>

        </ul>
    </div>
</section>

<section id="fullpage-sections">
    <section class="how-container-body" id="how-wrapper">
        <div class="container">
            <div class="list">

                <div class="text-center">
                    <?php
                    $k = 1;
                    if (get_field('fue_services_tabs')) :
                        while (has_sub_field('fue_services_tabs')) :
                            if ($k == 1) {
                                ?>
                                <span class="section-title two-lines"><?= get_sub_field('shortname') ?></span>
                    <?php
                            }
                            $k++;
                        endwhile;
                    endif;
                    ?>
                </div>
                <?php
                $k = 1;
                if (get_field('fue_services_tabs')) :
                    while (has_sub_field('fue_services_tabs')) :
                        if ($k == 1) {
                            ?>

                            <h2 class="text-center">

                                <span class="blue display-inline"><?= get_sub_field('shortname') ?></span>

                                <span class="black display-inline"><?= get_sub_field('title') ?></span>

                            </h2>
                        <?php
                                }
                                ?>
                <?php
                        $k++;
                    endwhile;
                endif;
                ?>
                <div class="transplant-list-wrapper">
                    <ul class="transplant-list">
                        <?php
                        $k = 1;
                        if (get_field('fue_hair_transplants_steps')) :
                            while (has_sub_field('fue_hair_transplants_steps')) :
                                $logoimage = wp_get_attachment_url(get_sub_field('image'));
                                ?>
                                <li class="transplant-list-item">
                                    <span class="step-image">
                                        <img src="<?php echo $logoimage; ?>" alt="Step1" />
                                    </span>
                                    <div class="step-info">
                                        <h6>Step <?= $k; ?></h6>
                                        <h4><?= get_sub_field('title'); ?></h4>
                                        <?= get_sub_field('descriptions'); ?>
                                    </div>
                                </li>
                        <?php
                                $k++;
                            endwhile;
                        endif;
                        ?>
                    </ul>
                </div>

            </div>
        </div>
        <div class="blue-time-wrapper">
            <div class="container">

                <span class="time-img">
                    <img src="<?php echo bloginfo('template_directory'); ?>/images/Our-Services/How-Long-Does.png" alt="How long does" />
                </span>
                <h4><span><?= get_field('time_title_in_blue'); ?></span> <?= get_field('time_title_in_black'); ?></h4>
                <p><?= get_field('time_descriptions'); ?></p>

            </div>
        </div>

    </section>
    <!-- end fue services -->
    <!-- start our exp section-->
    <section class="our-exp-wrapper right-candidate-wrapper" id="who-wrapper">

        <div class="our-exp-top-container">

            <div class="container">

                <div class="text-panel">

                    <span class="section-title">Who?</span>

                    <h2>

                        <span class="blue display-inline"><?= get_field('who_-_title_in_blue'); ?> </span>

                        <span class="black display-inline"><?= get_field('who_-_title_in_black'); ?></span>

                    </h2>

                    <p><?= get_field('who_-_descriptions'); ?></p>

                    <a href="<?= get_field('who_-_button_link'); ?>" class="btn btn-primary btn-readmore">Get Free Consultation<i class="fa fa-long-arrow-right"></i></a>
                </div>

                <div class="left-panel">

                    <div class="factor-wrapper">
                        <h4><?= get_field('other_factor_title'); ?></h4>
                        <ul>
                            <?php
                            $i = 1;
                            if (get_field('other_factor_process')) :
                                while (has_sub_field('other_factor_process')) :
                                    ?>
                                    <li>
                                        <span class="icon"></span>
                                        <span><?= get_sub_field('title'); ?></span>
                                    </li>
                            <?php
                                    $i++;
                                endwhile;
                            endif;
                            ?>
                        </ul>
                    </div>

                </div>

            </div>

        </div>

    </section>
    <!-- end our exp section-->
    <!-- start FUE experience-->
    <?php
    if ($slug == 'prp-therapy') {
        $style = "style='display:none;'";
    }
    if ($slug == 'eyebrow-transplantation') {
        $style = "style='display:none;'";
    }
    if ($slug == 'hair-transplant-for-women') {
        $style = "style='display:none;'";
    }
    ?>
    <section class="our-exp-wrapper fue-experience-video-outer-wrapper" id="experience-wrapper">

        <div class="our-exp-top-container">

            <div class="container">

                <div class="text-panel w-100">

                    <div class="text-center">

                        <span class="section-title two-lines">Our Media</span>

                    </div>

                    <h2 class="text-center">

                        <span class="blue display-inline"><?= get_field('after_treatment_sub_title') ? get_field('after_treatment_sub_title') : "Fue " ?> </span>

                        <span class="black display-inline">Experience</span>

                    </h2>

                    <p class="p1 text-center">BlueMagic Group, will make sure that you have the best experience with your hair transplant.</br> We have a reputation of carrying comparatively painless, minimally invasive products and we use the latest medical equipment and industry approved methods to provide their desired outcomes.</p>

                </div>

            </div>

        </div>

        <div class="fue-experience-video-wrapper">
            <div class="container">
                <div class="tab-body-wrapper">
                    <?php
                    // $i = 1;
                    // if (get_field('fuw_experience')) :
                    //     while (has_sub_field('fuw_experience')) :

                    $video_link = get_field('fuw_experience_video_link');
                    $id = substr($video_link, strrpos($video_link, '/') + 1);
                    $logoimage = "https://img.youtube.com/vi/" . $id . "/sddefault.jpg";
                    ?>
                    <div class="list " id="after-before">

                        <div class="video-wrapper">

                            <div class="video" style="background-image: url(<?php echo $logoimage; ?>)">

                                <!--<img style="border-radius: 35px;" src="<?php echo $logoimage; ?>" alt="Video-success" />-->

                            </div>

                            <span class="play-icon">

                                <a href="#after-before-modal11" rel="modal:open">

                                    <i class="fa fa-play"></i>

                                </a>

                            </span>

                        </div>

                    </div>
                    <?php
                    //         $i++;
                    //     endwhile;
                    // endif;
                    ?>

                    <?php
                    // $i = 1;
                    // if (get_field('fuw_experience')) :
                    //     while (has_sub_field('fuw_experience')) :
                    ?>
                    <div class="modal" id="after-before-modal11">

                        <div class="modal-overlay"></div>

                        <div class="moaal-body-wrapper">

                            <p>

                                <iframe src="<?= get_field('fuw_experience_video_link'); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                            </p>

                            <!-- <a href="#" rel="modal:close">Close</a> -->

                        </div>

                    </div>
                    <?php
                    //         $i++;
                    //     endwhile;
                    // endif;
                    ?>

                </div>
            </div>

            <ul <?= $style; ?> class="tab-title-wrapper">
                <?php
                $i = 1;
                if (get_field('fuw_experience')) :
                    while (has_sub_field('fuw_experience')) :
                        if ($i == 3) {
                            $style = "style='filter: grayscale(0) !important'";
                        } else {
                            $style = "";
                        }
                        ?>
                        <li class="tab-title-item-video111" <?= $style; ?>>
                            <a href="javascript:void(0);">
                                <img src="<?php echo wp_get_attachment_url(get_sub_field('image')); ?>" alt="Video1" />
                            </a>
                        </li>
                <?php
                        $i++;
                    endwhile;
                endif;
                ?>
            </ul>
        </div>

    </section>
    <!-- end FUE experience-->
    <!-- start our exp section-->
    <section class="our-exp-wrapper after-treatment-wrapper" id="after-fue-hair-transplant">
        <div class="our-exp-top-container">
            <div class="container">
                <div class="text-panel w-100 p-0">
                    <span class="section-title default-title-spacing"><?= get_field('after_treatment_section_title') ? get_field('after_treatment_section_title') : "After Treatment" ?></span>
                    <h2>
                        <span class="blue display-inline"><?= get_field('after_treatment_main_title') ? get_field('after_treatment_main_title') : "After Treatment " ?></span>
                        <span class="black display-inline"><?= get_field('after_treatment_sub_title') ? get_field('after_treatment_sub_title') : "After Treatment " ?></span>
                    </h2>
                    <ol class="treatment-list">
                        <?php
                        $i = 1;
                        if (get_field('after_treatment_steps')) :
                            while (has_sub_field('after_treatment_steps')) :
                                ?>
                                <li>
                                    <span class="number">
                                        <?php
                                                if ($i > 9) {
                                                    echo $i;
                                                } else {
                                                    echo '0' . $i;
                                                }
                                                ?>
                                    </span>
                                    <?= get_sub_field('descriptions'); ?>
                                </li>
                        <?php
                                $i++;
                            endwhile;
                        endif;
                        ?>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <!-- end our exp section-->
    <!-- start after exp section-->
    <section class="advantage-fue-wrapper" id="advantage-of-fue-wrapper">
        <span class="advantage-image">
            <img src="<?php echo wp_get_attachment_url(get_field('advantages_of_fue_image')); ?>" alt="Advantage" />
        </span>
        <div class="container">
            <div class="factor-wrapper">
                <h4><span class="blue"><?= get_field('advantages_of_fue_title_in_blue'); ?></span> <?= get_field('advantages_of_fue_title_in_black'); ?></h4>
                <ul>
                    <?php
                    $i = 1;
                    if (get_field('advantages_steps')) :
                        while (has_sub_field('advantages_steps')) :
                            ?>
                            <li>
                                <span class="icon"></span>
                                <?= get_sub_field('descriptions'); ?>
                            </li>
                    <?php
                            $i++;
                        endwhile;
                    endif;
                    ?>

                </ul>
            </div>
        </div>
    </section>
    <!-- end after exp section-->
    <!-- start faq-->
    <section class="our-exp-wrapper faq-wrapper" id="faqs-wrapper">
        <div class="our-exp-top-container">
            <div class="container">
                <div class="text-panel w-100">
                    <div class="text-center">
                        <span class="section-title two-lines"><?= get_field('frequently_asked_questions_title'); ?></span>
                    </div>
                    <h2 class="text-center">
                        <span class="blue display-inline">Frequently </span>
                        <span class="black display-inline">Asked Questions</span>
                    </h2>
                </div>
                <div class="faq-inner-wrapper">
                    <?php
                    $i = 1;
                    $args = array(
                        'type'                     => 'faq',
                        'child_of'                 => 0,
                        'parent'                   => '',
                        'orderby'                  => 'name',
                        'order'                    => 'DESC',
                        'hide_empty'               => 1,
                        'hierarchical'             => 1,
                        'pad_counts'               => false
                    );
                    $teamcats = get_categories($args);
                    // echo '<pre>';
                    // print_r($teamcats);
                    // echo '</pre>';
                    foreach ($teamcats as $t_post) :
                        if ($t_post->slug == get_post_field('post_name', get_post())) {
                            ?>
                            <?php
                                    $args = array(
                                        'cat' => $t_post->term_id,
                                        'post_type' => 'faq',
                                        'posts_per_page' => 8 // this will retrive all the post that is published 
                                    );
                                    $result = new WP_Query($args);
                                    while ($result->have_posts()) : $result->the_post() ?>
                                <?php $tid = get_the_ID(); ?>
                                <div class="faq-item">
                                    <h4 class="questions"><?= get_field('title', $tid); ?><span class="toggle-icon"></span></h4>
                                    <div class="faq-body">
                                        <p><?= get_field('descriptions', $tid); ?></p>
                                    </div>
                                </div>
                            <?php
                                    endwhile;
                                    wp_reset_postdata();

                                    $argss = array(
                                        'cat' => $t_post->term_id,
                                        'post_type' => 'faq',
                                        'posts_per_page' => -1 // this will retrive all the post that is published 
                                    );
                                    $results = new WP_Query($argss);

                                    if (count($results->posts) > 8) {
                                        ?>
                                <div class="text-center view-more-t-center">
                                    <a href="<?php echo BASE_URL ?>faq/" class="btn btn-primary btn-readmore">Know More <i class="fa fa-long-arrow-right"></i></a>
                                </div>
                    <?php
                            }
                        }
                    endforeach;
                    ?>

                </div>
            </div>
        </div>
    </section>
    <!-- end faq-->
</section>


<!-- start free consultant section-->

<section class="free-consultant-wrapper">

    <div class="container">

        <div class="text-wrapper">

            <h2 class="white-color">Get your FREE CONSULTATION!</h2>

            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>

        </div>

        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">

            <span>

                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>

                <span class="text">Get free consultation</span>

                <i class="fa fa-chevron-right"></i>

            </span>

        </a>

    </div>

</section>

<!--end free consultant section-->

<?php
get_footer();
