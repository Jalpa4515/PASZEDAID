<?php

/**
 * Template Name:  Our Media Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

<!-- start  breadcrumbs-->
<section class="breadcrumbs">
    <div class="container">
        <ul>
            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>
            <li class="active">Media</li>
        </ul>
    </div>
</section>
<!-- end breadcrumbs-->
<!-- start press and award tab-->
<section class="our-exp-wrapper media-award-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <h2>
                    <span class="blue display-inline">Our </span>
                    <span class="black display-inline">Media</span>
                </h2>
                <div class="media-inner-wrapper">
                    <div class="text-center f-btn-grp">
                        <button class="btn btn-default filter-button tab-title-item3 active activelink" data-tag="teamtm">Team</button>
                        <button class="btn btn-default filter-button tab-title-item3" data-tag="clinictm">Clinic</button>
                        <button class="btn btn-default filter-button tab-title-item3" data-tag="conferencetm">Operations</button>
                        <button class="btn btn-default filter-button tab-title-item3" data-tag="presstm">Our Patients</button>
                    </div>

                    <div class="media-tag-wrapper list" id="teamtm">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'teamt',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'media_center',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultteamt = new WP_Query($args);
                        ?>
                        <?php while ($resultteamt->have_posts()) : $resultteamt->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="media-tag-item">
                                <div class="media-image">
                                    <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                </div>
                                <div class="media-image-text">
                                    <a href="#<?= $tid; ?>modal" rel="modal:open"><i class="fa fa-search"></i></a>
                                    <p><?php echo get_field('title', $teid); ?></p>
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();


                        while ($resultteamt->have_posts()) : $resultteamt->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="modal" style="text-align: center;padding: 10px;background: #fff !important;" id="<?= $tid; ?>modal">
                                <div class="modal-overlay"></div>
                                <div class="moaal-body-wrapper">
                                    <p>
                                        <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                    </p>
                                    <!-- <a href="#" rel="modal:close">Close</a> -->
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>

                    <div class="media-tag-wrapper list" style="display:none;" id="clinictm">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'clinict',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'media_center',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultclinict = new WP_Query($args);
                        ?>
                        <?php while ($resultclinict->have_posts()) : $resultclinict->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="media-tag-item">
                                <div class="media-image">
                                    <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                </div>
                                <div class="media-image-text">
                                    <a href="#<?= $tid; ?>modal" rel="modal:open"><i class="fa fa-search"></i></a>
                                    <p><?php echo get_field('title', $teid); ?></p>
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();

                        while ($resultclinict->have_posts()) : $resultclinict->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="modal" style="text-align: center;padding: 10px;background: #fff !important;" id="<?= $tid; ?>modal">
                                <div class="modal-overlay"></div>
                                <div class="moaal-body-wrapper">
                                    <p>
                                        <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                    </p>
                                    <!-- <a href="#" rel="modal:close">Close</a> -->
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>

                    <div class="media-tag-wrapper list" style="display:none;" id="conferencetm">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'conferencet',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'media_center',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultconferencet = new WP_Query($args);
                        ?>
                        <?php while ($resultconferencet->have_posts()) : $resultconferencet->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="media-tag-item">
                                <div class="media-image">
                                    <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                </div>
                                <div class="media-image-text">
                                    <a href="#<?= $tid; ?>modal" rel="modal:open"><i class="fa fa-search"></i></a>
                                    <p><?php echo get_field('title', $teid); ?></p>
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();

                        while ($resultconferencet->have_posts()) : $resultconferencet->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="modal" style="text-align: center;padding: 10px;background: #fff !important;" id="<?= $tid; ?>modal">
                                <div class="modal-overlay"></div>
                                <div class="moaal-body-wrapper">
                                    <p>
                                        <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                    </p>
                                    <!-- <a href="#" rel="modal:close">Close</a> -->
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>

                    <div class="media-tag-wrapper list" style="display:none;" id="presstm">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'presst',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'media_center',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultpresst = new WP_Query($args);
                        ?>
                        <?php while ($resultpresst->have_posts()) : $resultpresst->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="media-tag-item">
                                <div class="media-image">
                                    <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                </div>
                                <div class="media-image-text">
                                    <a href="#<?= $tid; ?>modal" rel="modal:open"><i class="fa fa-search"></i></a>
                                    <p><?php echo get_field('title', $teid); ?></p>
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();

                        while ($resultpresst->have_posts()) : $resultpresst->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>

                            <div class="modal" style="text-align: center;padding: 10px;background: #fff !important;" id="<?= $tid; ?>modal">
                                <div class="modal-overlay"></div>
                                <div class="moaal-body-wrapper">
                                    <p>
                                        <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Media">
                                    </p>
                                    <!-- <a href="#" rel="modal:close">Close</a> -->
                                </div>
                            </div>

                        <?php endwhile;
                        wp_reset_postdata();
                        ?>
                    </div>

                </div>
            </div>
        </div>
</section>
<!-- end press and award tab-->
<!-- start free consultant section-->
<section class="free-consultant-wrapper">
    <div class="container">
        <div class="text-wrapper">
        <h2 class="white-color">Get your FREE CONSULTATION!</h2>
            <p class="white-color">Curious to know how your hair transplant would go? Connect with us today and let us help you understand each and everything with the help of a free consultation.  & let us give you complete details with the help of a free consultation.</p>
        </div>
        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
            <span>
                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                <span class="text">Get free consultation</span>
                <i class="fa fa-chevron-right"></i>
            </span>
        </a>
    </div>
</section>
<!--end free consultant section-->

<?php
get_footer();
