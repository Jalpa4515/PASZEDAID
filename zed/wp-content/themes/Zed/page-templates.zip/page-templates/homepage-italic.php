<?php

/**
 * Template Name: Homepage-ITALIC
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>
<?php
$bgimg = wp_get_attachment_url(get_field('banner'));
$banner_upper_image = wp_get_attachment_url(get_field('banner_upper_image'));
?>
<!-- start banner-->
<section class="banner-wrapper home_banner_wrapper" style="background-image: url(<?= $bgimg; ?>);background-size: cover;background-repeat: no-repeat;">
    <div class="container banner-outer-container">
        <div class="banner-info">
            <h1 class="banner-title">
                <span class="white-color">La tua esperienza alla Clinica Leader </span><span class="blue">nel Trapianto di Capelli a Istanbul</span>
                <!--<span class="white-color">(Turkey, Istanbul)</span>-->
            </h1>
            <?= get_field('descriptions'); ?>

            <a href="<?= get_field('button_link'); ?>" class="btn btn-primary"><i class="small-icon"></i> Prenota una consulenza gratuita</a>

            <?php
            $cookie_name = "googtrans";
            $commont = '#commoneng';
            $commontmobile = BASE_URL . '/wp-content/uploads/2021/02/BMG-Brochure-English.pdf';
            if (!isset($_COOKIE[$cookie_name])) {
                $commont = '#commoneng';
                $commontmobile = BASE_URL . '/wp-content/uploads/2021/02/BMG-Brochure-English.pdf';
            } else {
                if ($_COOKIE[$cookie_name] == '/en/sq') {
                    $commont = '#commonalb';
                    $commontmobile = BASE_URL . '/wp-content/uploads/2021/02/BMG-Brochure-Albanian.pdf';
                } else if ($_COOKIE[$cookie_name] == '/en/it') {
                    $commont = '#commonital';
                    $commontmobile = BASE_URL . '/wp-content/uploads/2021/02/BMG-Brochure-Italian.pdf';
                } else  if ($_COOKIE[$cookie_name] == '/en/es') {
                    $commont = '#commonspan';
                    $commontmobile = BASE_URL . '/wp-content/uploads/2021/02/BMG-Brochure-Spanish.pdf';
                } else {
                    $commont = '#commoneng';
                    $commontmobile = BASE_URL . '/wp-content/uploads/2021/02/BMG-Brochure-English.pdf';
                }
            }
            ?>

            <a href="<?= $commont; ?>" id="commonchangeatag" rel="modal:open" class="btn btn-secondary"><i class="small-icon-2"></i> Scarica la nostra brochure
</a>

            <a href="<?= $commontmobile; ?>" target="_blank" id="commonchangeatagmobile" class="btn btn-secondary"><i class="small-icon-2"></i>Scarica la nostra brochure
</a>

            <div class="modal" id="commoneng">
                <div class="modal-overlay"></div>
                <div class="moaal-body-wrapper">
                    <p>
                        <embed src="<?= BASE_URL; ?>/wp-content/uploads/2021/02/BMG-Brochure-English.pdf" style="width:100%;height:700px;">
                    </p>
                    <!-- <a href="#" rel="modal:close">Close</a> -->
                </div>
            </div>

            <div class="modal" id="commonalb">
                <div class="modal-overlay"></div>
                <div class="moaal-body-wrapper">
                    <p>
                        <embed src="<?= BASE_URL; ?>/wp-content/uploads/2021/02/BMG-Brochure-Albanian.pdf" style="width:100%;height:700px;">
                    </p>
                    <!-- <a href="#" rel="modal:close">Close</a> -->
                </div>
            </div>

            <div class="modal" id="commonital">
                <div class="modal-overlay"></div>
                <div class="moaal-body-wrapper">
                    <p>
                        <embed src="<?= BASE_URL; ?>/wp-content/uploads/2021/02/BMG-Brochure-Italian.pdf" style="width:100%;height:700px;">
                    </p>
                    <!-- <a href="#" rel="modal:close">Close</a> -->
                </div>
            </div>

            <div class="modal" id="commonspan">
                <div class="modal-overlay"></div>
                <div class="moaal-body-wrapper">
                    <p>
                        <embed src="<?= BASE_URL; ?>/wp-content/uploads/2021/02/BMG-Brochure-Spanish.pdf" style="width:100%;height:700px;">
                    </p>
                    <!-- <a href="#" rel="modal:close">Close</a> -->
                </div>
            </div>

            <div class="provider-info">
                <a href="javascript:void(0)">
                    <img src="<?php echo wp_get_attachment_url(get_field('image1')); ?>" alt="Customer Choice" />
                </a>
                <a href="javascript:void(0)">
                    <img src="<?php echo wp_get_attachment_url(get_field('image2')); ?>" alt="Top Service Prvoider" />
                </a>
            </div>
        </div>
        <div class="banner-profile-image">
            <img src="<?= $banner_upper_image; ?>" alt="Profile" />
        </div>
    </div>
</section>
<!-- end banner-->
<!--rating info-->
<section class="rating-container">
    <div class="container">
        <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/google.png" alt="Google" /></a>
        <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/trustpiolet.png" alt="Trust Piolet" /></a>
        <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/provenExport.png" alt="Proven Expert" /></a>
    </div>
</section>
<!--end raing info-->
<!-- start our exp section-->
<section class="our-exp-wrapper home-our-exp-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="left-panel">
                <span class="exp-banner">
                    <a href="#common-modal" rel="modal:open">
                        <img src="<?php echo wp_get_attachment_url(get_field('experience_image')); ?>" alt="Our-Exp-Left" />
                    </a>
                </span>
                <span class="exp-logo">
                    <img src="<?php echo bloginfo('template_directory'); ?>/images/our-exp-left-logo.png" alt="Our-Exp-Logo" />
                </span>
            </div>
            <div class="text-panel">
                <span class="section-title">La nostra esperienza</span>
                <h2>
                    <span class="blue"><?= get_field('experience_title_in_blue'); ?></span>
                    <span class="black"><?= get_field('experience_title_in_black'); ?></span>
                </h2>
                <?= get_field('experience_decriptions'); ?>
                <a href="<?= get_field('experience_button_link'); ?>" class="btn btn-primary btn-readmore">
Leggi di più <i class="fa fa-long-arrow-right"></i></a>
            </div>
        </div>
    </div>
    <div class="our-exp-bottom-container">
        <div class="container">
            <h2>Come visto in </h2>
            <div class="logos-list" id="logo-list">
                <?php
                $args = array(
                    'post_type' => 'in_press',
                    'posts_per_page' => -1 // this will retrive all the post that is published 
                );
                $resultpremium = new WP_Query($args);

                while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                    <?php $tid = get_the_ID();
                        if (get_the_title($tid) == 'Class' || get_the_title($tid) == 'Accesswire') { } else {
                            ?>
                        <div>
                            <a href="javascript:void(0)"><img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="P2" /></a>
                        </div>

                <?php
                    }
                endwhile;
                ?>
            </div>
        </div>
    </div>
</section>
<!-- end our exp section-->
<!-- start specialities service slider-->
<section class="specialities-service-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">I nostri servizi</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">BlueMagic</span>
                    <span class="black display-inline">Specialità</span>
                </h2>
                <div class="text-center">
                    <p>BlueMagic Group fornisce trapianti di capelli di qualità a tutti nel Regno Unito e nel mondo
</p>
                </div>
            </div>
        </div>
    </div>
    <div class="specialities-service-slider">
        <div class="container">
            <div class="slider-nav">

                <?php
                $args = array(
                    'post_type' => 'specialities',
                    // 'orderby' => 'meta_value order',
                    // 'order' => 'ASC',
                    'orderby'     => array('meta_value' => 'ASC', 'order' => 'ASC'),
                    'posts_per_page' => -1 // this will retrive all the post that is published 
                );
                $resultt = new WP_Query($args);
                $i = 1;
                while ($resultt->have_posts()) : $resultt->the_post();
                    $p_post = get_the_ID();
                    $imagep = wp_get_attachment_url(get_field('image', $p_post));
                    ?>
                    <div>
                        <div class="nav-slider-item">
                            <span class="icon"><img src="<?= $imagep; ?>" /></span>
                            <span><?= get_field('title', $p_post); ?></span>
                        </div>
                    </div>
                <?php
                    $i++;
                endwhile;
                wp_reset_postdata();
                ?>

            </div>
            <div class="slider-for">
                <?php
                $args = array(
                    'post_type' => 'specialities',
                    // 'orderby' => 'ID',
                    // 'order' => 'ASC',
                    'orderby'     => array('meta_value' => 'ASC', 'order' => 'ASC'),
                    'posts_per_page' => -1 // this will retrive all the post that is published 
                );
                $resultt = new WP_Query($args);
                $i = 1;
                while ($resultt->have_posts()) : $resultt->the_post();
                    $p_post = get_the_ID();
                    $imagep = wp_get_attachment_url(get_field('image', $p_post));
                    ?>
                    <div>
                        <div class="slider-info">
                            <h5><?= get_field('title', $p_post); ?></h5>
                            <?= get_field('descriptions', $p_post); ?>
                            <a href="<?= get_field('page_link', $p_post); ?>">Leggi di più
<i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                <?php
                    $i++;
                endwhile;
                wp_reset_postdata();
                ?>

            </div>
        </div>
    </div>

</section>
<!-- end specialities service slider-->
<!-- start our exp section-->
<section class="our-exp-wrapper about-us-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel">
                <span class="section-title">Chi siamo
</span>
                <h2>
                    <span class="blue"><?= get_field('about_us_title_in_blue'); ?></span>
                    <span class="black"><?= get_field('about_us_title_in_black'); ?></span>
                </h2>
                <?= get_field('about_us_description'); ?>
                <a href="<?= get_field('about_us_link'); ?>" class="btn btn-primary btn-readmore">Leggi di più
 <i class="fa fa-long-arrow-right"></i></a>
            </div>
            <div class="left-panel">
                <span class="exp-banner">
                    <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('about_us_image')); ?>" alt="About Us" />
                </span>
                <span class="exp-logo">
                    <img src="<?php echo bloginfo('template_directory'); ?>/images/our-exp-left-logo.png" alt="Our-Exp-Logo" />
                </span>
            </div>
        </div>
    </div>
</section>
<!-- end our exp section-->
<!-- start counnter section-->
<section class="counter-wrapper">
    <div class="container">

        <ul id="counter">

            <li>

                <span class="icon"><img src="<?php echo bloginfo('template_directory'); ?>/images/counnter-icon-1.png" alt="Exp" /></span>

                <div class="icon-info">

                    <strong class="counter-value" data-count="<?php echo esc_attr(get_option('yearofexp')); ?>">0</strong>

                    <span>Anni di esperienza Sterling
</span>

                </div>

            </li>

            <li>

                <span class="icon"><img src="<?php echo bloginfo('template_directory'); ?>/images/counnter-icon-2.png" alt="Exp" /></span>

                <div class="icon-info">

                    <strong class="counter-value" data-count="<?php echo esc_attr(get_option('hairtransplantation')); ?>">0</strong>

                    <span>Trapianti di successo
</span>

                </div>

            </li>

            <li>

                <span class="icon"><img src="<?php echo bloginfo('template_directory'); ?>/images/counnter-icon-3.png" alt="Exp" /></span>

                <div class="icon-info">

                    <strong class="counter-value" data-count="<?php echo esc_attr(get_option('daysupport')); ?>">0</strong>

                    <span>Giorni di supporto completo
</span>

                </div>

            </li>

        </ul>

    </div>
</section>
<!-- end counter section-->
<!-- start before after service slider-->
<section class="before-after-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel">
                <span class="section-title">Risultati prima e dopo
</span>
                <h2>
                    <span class="blue display-inline">BlueMagic Group</span>
                    <span class="black display-inline">Successo</span>
                </h2>
            </div>
        </div>
    </div>
    <div class="after-before-slider-wrapper">
        <div class="container">
            <div class="slider-after-before">
                <?php
                if (get_field('bluemagic_success')) :
                    while (has_sub_field('bluemagic_success')) :
                        $logoimage = wp_get_attachment_url(get_sub_field('image'));
                        ?>
                        <div>
                            <div class="slider-info">
                                <div class="slider-left">
                                    <img src="<?php echo $logoimage; ?>" alt="After-Before" />
                                </div>
                                <div class="slider-right">
                                    <h5><?= get_sub_field('title'); ?></h5>
                                    <?= get_sub_field('description'); ?>
                                    <a href="<?= get_sub_field('button_link'); ?>" class="btn btn-primary btn-readmore">Visualizza altri risultati
 <i class="fa fa-long-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                <?php
                    endwhile;
                endif;
                ?>

            </div>
        </div>
    </div>
</section>
<!-- end before after service slider-->
<!-- start before after service slider-->
<section class="our-exp-wrapper testimonial-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Il cliente ci ama
</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Paziente </span>
                    <span class="black display-inline">Testimonianze</span>
                </h2>
            </div>
        </div>
        <div class="rating-container">
            <div class="container">
                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/google.png" alt="Google"></a>
                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/trustpiolet.png" alt="Trust Piolet"></a>
                <a href="javascript:void(0)"><img src="<?php echo bloginfo('template_directory'); ?>/images/provenExport.png" alt="Proven Expert"></a>
            </div>
        </div>
        <div class="testimonial-slider-wrapper">
            <div class="container">

                <div class="testimonial-slider">

                    <?php
                    $args = array(
                        'post_type' => 'testimonials',
                        // 'orderby'     => array('meta_value' => 'ASC', 'order' => 'ASC'),
                        'orderby' => 'post_date',
                        'order'   => 'ASC',
                        'posts_per_page' => -1, // this will retrive all the post that is published 
                    );
                    $resultt = new WP_Query($args);
                    // echo '<pre>';
                    // print_r($resultt);
                    // echo '</pre>';
                    while ($resultt->have_posts()) : $resultt->the_post();
                        $teid = get_the_ID();
                        if ((get_field('country_name', $teid) == 'Portugal') || (get_field('country_name', $teid) == 'Serbia')  || (get_field('country_name', $teid) == 'Japan')  || (get_field('country_name', $teid) == 'United Kingdom')  || (get_field('country_name', $teid) == 'Ireland')  || (get_field('country_name', $teid) == 'Uganda')  || (get_field('country_name', $teid) == 'Italy')  || (get_field('country_name', $teid) == 'Albania')  || (get_field('country_name', $teid) == 'India')  || (get_field('country_name', $teid) == 'Brazil')  || (get_field('country_name', $teid) == 'Spain')  || (get_field('country_name', $teid) == 'France')) {
                            ?>
                            <div>

                                <div class="slider-info">

                                    <!--  viken - 22/01/2021 work start -->

                                    <h5 class="display-inline"><?= get_field('testimonial_title', $teid); ?></h5>

                                    <!--  viken - 22/01/2021 work end -->

                                    <div class="slider-left">

                                        <?php $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>

                                        <img src="<?php echo $imagepv; ?>" alt="Testimonial" />

                                    </div>

                                    <?= get_field('descriptions', $teid); ?>


                                    <div class="blockquote-bg-wrapper">
                                        <h5 class="display-inline">- <?= get_field('full_name', $teid); ?></h5>

                                        <!--  viken - 22/01/2021 work start -->

                                        <h5 class="display-inline">- <?= get_field('country_name', $teid); ?></h5>

                                        <span class="flag-icon">

                                            <?php $flagIcon = wp_get_attachment_url(get_field('flag_icon', $teid)); ?>

                                            <img src="<?php echo $flagIcon; ?>" />

                                        </span>

                                    </div>

                                    <!--  viken - 22/01/2021 work end -->

                                </div>

                            </div>
                        <?php
                            }
                            ?>


                    <?php endwhile;
                    wp_reset_postdata();
                    ?>


                </div>
            </div>
        </div>
        <div class="text-center view-more-t-center">
            <a href="<?= BASE_URL ?>testimonial/" class="btn btn-primary btn-readmore">Visualizza altro
 <i class="fa fa-long-arrow-right"></i></a>
        </div>
    </div>
</section>
<!-- end before after service slider-->
<!-- start fixed payment section-->
<?php
$flex_banner = wp_get_attachment_url(get_field('flex_banner'));
?>
<section class="our-exp-wrapper fixed-payment-wrapper" class="banner-wrapper common-banner-wrapper" style="background: url(<?= $flex_banner; ?>) no-repeat 80% 10% !important;">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel">
                <span class="section-title white-color">Struttura di pagamento flessibile
</span>
                <h2 class="fs-55">
                    <span class="blue"><?= get_field('fixed_payment_title_in_blue'); ?> <span class="white-color display-inline"><?= get_field('fixed_payment_title_in_white'); ?> </span></span>
                </h2>
                <h3><?= get_field('fixed_payment_subtitle'); ?></h3>
                <a href="<?= get_field('fixed_payment_button_link'); ?>" class="btn btn-primary btn-readmore">Learn More <i class="fa fa-long-arrow-right"></i></a>
            </div>
            <!-- <div class="profile-image-wrapper">
                <img src="<?php echo bloginfo('template_directory'); ?>/images/fixed-payment-profile-img.png" alt="Fixed Payment" />
            </div> -->
        </div>
    </div>
</section>
<!-- end fixed payment section-->
<!-- start before after service slider-->
<section class="our-exp-wrapper media-center-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Media</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Abbiamo tutte le informazioni di cui hai bisogno
</span>
                    <span class="black display-inline">Trapianto di capelli!
</span>
                </h2>
                <div class="text-center">
                    <p>Scopri come il nostro team lavorerà al meglio per aiutarti a ottenere l'aspetto desiderato
</p>
                </div>
                <div class="text-center f-btn-grp">
                    <button class="btn btn-default filter-button tab-title-item2 active activelink" data-tag="teamt">Squadra</button>
                    <button class="btn btn-default filter-button tab-title-item2" data-tag="clinict">Clinica</button>
                    <button class="btn btn-default filter-button tab-title-item2" data-tag="conferencet">Operazioni</button>
                    <button class="btn btn-default filter-button tab-title-item2" data-tag="presst">I nostri pazienti
</button>
                </div>
                <div class="media-slider-wrapper">
                    <div class="media-slider2">
                        <div class="team-member-slider list" id="teamt">
                            <?php
                            $args = array(
                                'meta_query' => array(
                                    array(
                                        'key' => 'type',
                                        'value' => 'teamt',
                                        'compare' => 'LIKE'
                                    )
                                ),
                                'post_type' => 'media_center',
                                'posts_per_page' => -1 // this will retrive all the post that is published 
                            );
                            $resultteamt = new WP_Query($args);
                            ?>
                            <?php while ($resultteamt->have_posts()) : $resultteamt->the_post(); ?>
                                <?php $tidv = get_the_ID(); ?>

                                <div>
                                    <div class="slider-info">
                                        <img height="250" width="375" src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teidv)); ?>" alt="slider" />
                                    </div>
                                </div>

                            <?php endwhile;
                            wp_reset_postdata();
                            ?>
                        </div>

                        <div class="team-member-slider list hide" id="clinict">
                            <?php
                            $args = array(
                                'meta_query' => array(
                                    array(
                                        'key' => 'type',
                                        'value' => 'clinict',
                                        'compare' => 'LIKE'
                                    )
                                ),
                                'post_type' => 'media_center',
                                'posts_per_page' => -1 // this will retrive all the post that is published 
                            );
                            $resultclinict = new WP_Query($args);
                            ?>
                            <?php while ($resultclinict->have_posts()) : $resultclinict->the_post(); ?>
                                <?php $teidv = get_the_ID(); ?>

                                <div>
                                    <div class="slider-info">
                                        <img height="250" width="375" src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teidv)); ?>" alt="slider" />
                                    </div>
                                </div>

                            <?php endwhile;
                            wp_reset_postdata();
                            ?>
                        </div>

                        <div class="team-member-slider list hide" id="conferencet">
                            <?php
                            $args = array(
                                'meta_query' => array(
                                    array(
                                        'key' => 'type',
                                        'value' => 'conferencet',
                                        'compare' => 'LIKE'
                                    )
                                ),
                                'post_type' => 'media_center',
                                'posts_per_page' => -1 // this will retrive all the post that is published 
                            );
                            $resultconferencet = new WP_Query($args);
                            ?>
                            <?php while ($resultconferencet->have_posts()) : $resultconferencet->the_post(); ?>
                                <?php $teidv = get_the_ID(); ?>

                                <div>
                                    <div class="slider-info">
                                        <img height="250" width="375" src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teidv)); ?>" alt="slider" />
                                    </div>
                                </div>

                            <?php endwhile;
                            wp_reset_postdata();
                            ?>
                        </div>

                        <div class="team-member-slider list hide" id="presst">
                            <?php
                            $args = array(
                                'meta_query' => array(
                                    array(
                                        'key' => 'type',
                                        'value' => 'presst',
                                        'compare' => 'LIKE'
                                    )
                                ),
                                'post_type' => 'media_center',
                                'posts_per_page' => -1 // this will retrive all the post that is published 
                            );
                            $resultpresst = new WP_Query($args);
                            ?>
                            <?php while ($resultpresst->have_posts()) : $resultpresst->the_post(); ?>
                                <?php $teidv = get_the_ID(); ?>

                                <div>
                                    <div class="slider-info">
                                        <img height="250" width="375" src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teidv)); ?>" alt="slider" />
                                    </div>
                                </div>

                            <?php endwhile;
                            wp_reset_postdata();
                            ?>
                        </div>
                    </div>
                </div>
                <div class="text-center">
                    <a href="<?= BASE_URL ?>our-media" class="btn btn-primary btn-readmore">Visualizza di più
 <i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end before after service slider-->
<!-- start our book section-->
<section class="our-exp-wrapper our-book-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="left-panel"></div>
            <span class="exp-banner">
                <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('our_book_image')); ?>" alt="Our-Book" />
            </span>
            <div class="text-panel">
                <span class="section-title">Leggi il nostro libro!
</span>
                <h2>
                    <span class="blue"><?= get_field('our_book_title_in_blue'); ?></span>
                    <span class="black"><?= get_field('our_book_title_in_black'); ?></span>
                </h2>
                <?= get_field('our_book_descriptions'); ?>
                <div class="amazon-partner-link-wrapper">
                    <a href="https://www.amazon.com/NEED-KNOW-ABOUT-HAIR-TRANSPLANT-dp-1527267547/dp/1527267547/ref=mt_other?_encoding=UTF8&me=&qid=" target="_blank"><img src="<?php echo bloginfo('template_directory'); ?>/images/amazon1.png" alt="Amazon"></a>
                    <a href="https://www.amazon.com/NEED-KNOW-ABOUT-HAIR-TRANSPLANT-ebook-dp-B08D2GPMHF/dp/B08D2GPMHF/ref=mt_other?_encoding=UTF8&me=&qid=" target="_blank"><img src="<?php echo bloginfo('template_directory'); ?>/images/amazon2.png" alt="Amazon"></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end our book section-->
<!-- start our news section-->
<section class="our-exp-wrapper our-news-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Leggi i nostri blog!
</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">BlueMagic</span>
                    <span class="black display-inline">notizia</span>
                </h2>
                <div class="text-center">
                    <p>Scopri di più sul mondo della<b>procedura di trapianto di capelli</b> e su BlueMagic Group per scoprire quale trattamento sarebbe più adatto a te e al tuo desiderio di capelli spessi e lunghi!</p>
                </div>
                <div class="blog-list-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 3 // this will retrive all the post that is published 
                    );
                    $resulttc = new WP_Query($args);
                    if ($resulttc->have_posts()) {
                        while ($resulttc->have_posts()) : $resulttc->the_post();
                            $IDr = get_the_ID();
                            ?>
                            <div class="box-list-item">
                                <span class="blog-image">
                                    <img src="<?php echo get_the_post_thumbnail_url($IDr); ?>" alt="Blog" />
                                </span>
                                <span class="blog-date"><?php echo get_the_time('M d, Y', $IDr); ?></span>
                                <h4><?php echo get_the_title($IDr); ?></h4>
                                <a href="<?= get_the_permalink($IDr); ?>">Read more <i class="fa fa-long-arrow-right"></i></a>
                            </div>
                    <?php
                        endwhile;
                    }
                    ?>
                </div>
                <div class="text-center">
                    <a href="<?= BASE_URL . 'blog'; ?>" class="btn btn-primary btn-readmore">Visualizza di più
 <i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end our news section-->

<!-- start get inttouch form-->
<section class="our-exp-wrapper get-in-touch-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel">
                <span class="section-title">Mettiti in contatto
</span>
                <h2>
                    <span class="blue">Sognando il tuo
 <br /> bei capelli già?
</span>
                    <span class="black">Connettiti con noi ora!
</span>
                </h2>
                <div class="get-in-touch-info">
                    <div class="get-in-touch-item">
                        <span class="icon-overlay">
                            <img src="<?php echo bloginfo('template_directory'); ?>/images/call-icon.png" alt="Call" />
                        </span>
                        <div class="icon-info-text">
                            <span>Telefono</span>
                            <h5><a href="tel:<?php echo esc_attr(get_option('phonenumber')); ?>"><?php echo esc_attr(get_option('phonenumber')); ?></a></h5>
                        </div>
                    </div>
                    <div class="get-in-touch-item">
                        <span class="icon-overlay">
                            <img src="<?php echo bloginfo('template_directory'); ?>/images/mail-icon.png" alt="mail" />
                        </span>
                        <div class="icon-info-text">
                            <span>Email</span>
                            <h5><a href="mailto:<?php echo esc_attr(get_option('emailid')); ?>"><?php echo esc_attr(get_option('emailid')); ?></a></h5>
                        </div>
                    </div>
                    <div class="get-in-touch-item">
                        <span class="icon-overlay">
                            <img src="<?php echo bloginfo('template_directory'); ?>/images/clock-icon.png" alt="clock" />
                        </span>
                        <div class="icon-info-text">
                            <span>Orario di apertura
</span>
                            <h5><?php echo esc_attr(get_option('openhours')); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-panel">
                <form name="contact-formm" method="POST">
                    <div class="form-group">
                        <i class="fa fa-user-o"></i>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Your Full Name" />
                        <span id="error_name"></span>
                    </div>
                    <div class="form-group">
                        <i class="fa fa-angle-down pn"></i>
                        <select class="form-control phone-number" id="county_code" name="county_code">
                            <option data-countryCode="GB" value="44">+44</option>
                            <option data-countryCode="IT" value="39">+39</option>
                            <option data-countryCode="AT" value="43">+43</option>
                            <option data-countryCode="AZ" value="994">+994</option>
                            <option data-countryCode="BS" value="1242">+1242</option>
                            <option data-countryCode="DZ" value="213">+213</option>
                            <option data-countryCode="AD" value="376">+376</option>
                            <option data-countryCode="AO" value="244">+244</option>
                            <option data-countryCode="AI" value="1264">+1264</option>
                            <option data-countryCode="AG" value="1268">+1268</option>
                            <option data-countryCode="AR" value="54">+54</option>
                            <option data-countryCode="AM" value="374">+374</option>
                            <option data-countryCode="AW" value="297">+297</option>
                            <option data-countryCode="AU" value="61">+61</option>
                            <option data-countryCode="BH" value="973">+973</option>
                            <option data-countryCode="BD" value="880">+880</option>
                            <option data-countryCode="BB" value="1246">+1246</option>
                            <option data-countryCode="BY" value="375">+375</option>
                            <option data-countryCode="BE" value="32">+32</option>
                            <option data-countryCode="BZ" value="501">+501</option>
                            <option data-countryCode="BJ" value="229">+229</option>
                            <option data-countryCode="BM" value="1441">+1441</option>
                            <option data-countryCode="BT" value="975">+975</option>
                            <option data-countryCode="BO" value="591">+591</option>
                            <option data-countryCode="BA" value="387">+387</option>
                            <option data-countryCode="BW" value="267">+267</option>
                            <option data-countryCode="BR" value="55">+55</option>
                            <option data-countryCode="BN" value="673">+673</option>
                            <option data-countryCode="BG" value="359">+359</option>
                            <option data-countryCode="BF" value="226">+226</option>
                            <option data-countryCode="BI" value="257">+257</option>
                            <option data-countryCode="KH" value="855">+855</option>
                            <option data-countryCode="CM" value="237">+237</option>
                            <option data-countryCode="CA" value="1">+1</option>
                            <option data-countryCode="CV" value="238">+238</option>
                            <option data-countryCode="KY" value="1345">+1345</option>
                            <option data-countryCode="CF" value="236">+236</option>
                            <option data-countryCode="CL" value="56">+56</option>
                            <option data-countryCode="CN" value="86">+86</option>
                            <option data-countryCode="CO" value="57">+57</option>
                            <option data-countryCode="KM" value="269">+269</option>
                            <option data-countryCode="CG" value="242">+242</option>
                            <option data-countryCode="CK" value="682">+682</option>
                            <option data-countryCode="CR" value="506">+506</option>
                            <option data-countryCode="HR" value="385">+385</option>
                            <option data-countryCode="CU" value="53">+53</option>
                            <option data-countryCode="CY" value="90392">+90392</option>
                            <option data-countryCode="CY" value="357">+357</option>
                            <option data-countryCode="CZ" value="42">+42</option>
                            <option data-countryCode="DK" value="45">+45</option>
                            <option data-countryCode="DJ" value="253">+253</option>
                            <option data-countryCode="DM" value="1809">+1809</option>
                            <option data-countryCode="DO" value="1809">+1809</option>
                            <option data-countryCode="EC" value="593">+593</option>
                            <option data-countryCode="EG" value="20">+20</option>
                            <option data-countryCode="SV" value="503">+503</option>
                            <option data-countryCode="GQ" value="240">+240</option>
                            <option data-countryCode="ER" value="291">+291</option>
                            <option data-countryCode="EE" value="372">+372</option>
                            <option data-countryCode="ET" value="251">+251</option>
                            <option data-countryCode="FK" value="500">+500</option>
                            <option data-countryCode="FO" value="298">+298</option>
                            <option data-countryCode="FJ" value="679">+679</option>
                            <option data-countryCode="FI" value="358">+358</option>
                            <option data-countryCode="FR" value="33">+33</option>
                            <option data-countryCode="GF" value="594">+594</option>
                            <option data-countryCode="PF" value="689">+689</option>
                            <option data-countryCode="GA" value="241">+241</option>
                            <option data-countryCode="GM" value="220">+220</option>
                            <option data-countryCode="GE" value="7880">+7880</option>
                            <option data-countryCode="DE" value="49">+49</option>
                            <option data-countryCode="GH" value="233">+233</option>
                            <option data-countryCode="GI" value="350">+350</option>
                            <option data-countryCode="GR" value="30">+30</option>
                            <option data-countryCode="GL" value="299">+299</option>
                            <option data-countryCode="GD" value="1473">+1473</option>
                            <option data-countryCode="GP" value="590">+590</option>
                            <option data-countryCode="GU" value="671">+671</option>
                            <option data-countryCode="GT" value="502">+502</option>
                            <option data-countryCode="GN" value="224">+224</option>
                            <option data-countryCode="GW" value="245">+245</option>
                            <option data-countryCode="GY" value="592">+592</option>
                            <option data-countryCode="HT" value="509">+509</option>
                            <option data-countryCode="HN" value="504">+504</option>
                            <option data-countryCode="HK" value="852">+852</option>
                            <option data-countryCode="HU" value="36">+36</option>
                            <option data-countryCode="IS" value="354">+354</option>
                            <option data-countryCode="IN" value="91">+91</option>
                            <option data-countryCode="ID" value="62">+62</option>
                            <option data-countryCode="IR" value="98">+98</option>
                            <option data-countryCode="IQ" value="964">+964</option>
                            <option data-countryCode="IE" value="353">+353</option>
                            <option data-countryCode="IL" value="972">+972</option>
                            <option data-countryCode="JM" value="1876">+1876</option>
                            <option data-countryCode="JP" value="81">+81</option>
                            <option data-countryCode="JO" value="962">+962</option>
                            <option data-countryCode="KZ" value="7">+7</option>
                            <option data-countryCode="KE" value="254">+254</option>
                            <option data-countryCode="KI" value="686">+686</option>
                            <option data-countryCode="KP" value="850">+850</option>
                            <option data-countryCode="KR" value="82">+82</option>
                            <option data-countryCode="KW" value="965">+965</option>
                            <option data-countryCode="KG" value="996">+996</option>
                            <option data-countryCode="LA" value="856">+856</option>
                            <option data-countryCode="LV" value="371">+371</option>
                            <option data-countryCode="LB" value="961">+961</option>
                            <option data-countryCode="LS" value="266">+266</option>
                            <option data-countryCode="LR" value="231">+231</option>
                            <option data-countryCode="LY" value="218">+218</option>
                            <option data-countryCode="LI" value="417">+417</option>
                            <option data-countryCode="LT" value="370">+370</option>
                            <option data-countryCode="LU" value="352">+352</option>
                            <option data-countryCode="MO" value="853">+853</option>
                            <option data-countryCode="MK" value="389">+389</option>
                            <option data-countryCode="MG" value="261">+261</option>
                            <option data-countryCode="MW" value="265">+265</option>
                            <option data-countryCode="MY" value="60">+60</option>
                            <option data-countryCode="MV" value="960">+960</option>
                            <option data-countryCode="ML" value="223">+223</option>
                            <option data-countryCode="MT" value="356">+356</option>
                            <option data-countryCode="MH" value="692">+692</option>
                            <option data-countryCode="MQ" value="596">+596</option>
                            <option data-countryCode="MR" value="222">+222</option>
                            <option data-countryCode="YT" value="269">+269</option>
                            <option data-countryCode="MX" value="52">+52</option>
                            <option data-countryCode="FM" value="691">+691</option>
                            <option data-countryCode="MD" value="373">+373</option>
                            <option data-countryCode="MC" value="377">+377</option>
                            <option data-countryCode="MN" value="976">+976</option>
                            <option data-countryCode="MS" value="1664">+1664</option>
                            <option data-countryCode="MA" value="212">+212</option>
                            <option data-countryCode="MZ" value="258">+258</option>
                            <option data-countryCode="MN" value="95">+95</option>
                            <option data-countryCode="NA" value="264">+264</option>
                            <option data-countryCode="NR" value="674">+674</option>
                            <option data-countryCode="NP" value="977">+977</option>
                            <option data-countryCode="NL" value="31">+31</option>
                            <option data-countryCode="NC" value="687">+687</option>
                            <option data-countryCode="NZ" value="64">+64</option>
                            <option data-countryCode="NI" value="505">+505</option>
                            <option data-countryCode="NE" value="227">+227</option>
                            <option data-countryCode="NG" value="234">+234</option>
                            <option data-countryCode="NU" value="683">+683</option>
                            <option data-countryCode="NF" value="672">+672</option>
                            <option data-countryCode="NP" value="670">+670</option>
                            <option data-countryCode="NO" value="47">+47</option>
                            <option data-countryCode="OM" value="968">+968</option>
                            <option data-countryCode="PW" value="680">+680</option>
                            <option data-countryCode="PA" value="507">+507</option>
                            <option data-countryCode="PG" value="675">+675</option>
                            <option data-countryCode="PY" value="595">+595</option>
                            <option data-countryCode="PE" value="51">+51</option>
                            <option data-countryCode="PH" value="63">+63</option>
                            <option data-countryCode="PL" value="48">+48</option>
                            <option data-countryCode="PT" value="351">+351</option>
                            <option data-countryCode="PR" value="1787">+1787</option>
                            <option data-countryCode="QA" value="974">+974</option>
                            <option data-countryCode="RE" value="262">+262</option>
                            <option data-countryCode="RO" value="40">+40</option>
                            <option data-countryCode="RU" value="7">+7</option>
                            <option data-countryCode="RW" value="250">+250</option>
                            <option data-countryCode="SM" value="378">+378</option>
                            <option data-countryCode="ST" value="239">+239</option>
                            <option data-countryCode="SA" value="966">+966</option>
                            <option data-countryCode="SN" value="221">+221</option>
                            <option data-countryCode="CS" value="381">+381</option>
                            <option data-countryCode="SC" value="248">+248</option>
                            <option data-countryCode="SL" value="232">+232</option>
                            <option data-countryCode="SG" value="65">+65</option>
                            <option data-countryCode="SK" value="421">+421</option>
                            <option data-countryCode="SI" value="386">+386</option>
                            <option data-countryCode="SB" value="677">+677</option>
                            <option data-countryCode="SO" value="252">+252</option>
                            <option data-countryCode="ZA" value="27">+27</option>
                            <option data-countryCode="ES" value="34">+34</option>
                            <option data-countryCode="LK" value="94">+94</option>
                            <option data-countryCode="SH" value="290">+290</option>
                            <option data-countryCode="KN" value="1869">+1869</option>
                            <option data-countryCode="SC" value="1758">+1758</option>
                            <option data-countryCode="SD" value="249">+249</option>
                            <option data-countryCode="SR" value="597">+597</option>
                            <option data-countryCode="SZ" value="268">+268</option>
                            <option data-countryCode="SE" value="46">+46</option>
                            <option data-countryCode="CH" value="41">+41</option>
                            <option data-countryCode="SI" value="963">+963</option>
                            <option data-countryCode="TW" value="886">+886</option>
                            <option data-countryCode="TJ" value="7">+7</option>
                            <option data-countryCode="TH" value="66">+66</option>
                            <option data-countryCode="TG" value="228">+228</option>
                            <option data-countryCode="TO" value="676">+676</option>
                            <option data-countryCode="TT" value="1868">+1868</option>
                            <option data-countryCode="TN" value="216">+216</option>
                            <option data-countryCode="TR" value="90">+90</option>
                            <option data-countryCode="TM" value="7">+7</option>
                            <option data-countryCode="TM" value="993">+993</option>
                            <option data-countryCode="TC" value="1649">+1649</option>
                            <option data-countryCode="TV" value="688">+688</option>
                            <option data-countryCode="UG" value="256">+256</option>
                            <option data-countryCode="UA" value="380">+380</option>
                            <option data-countryCode="AE" value="971">+971</option>
                            <option data-countryCode="UY" value="598">+598</option>
                            <option data-countryCode="US" value="1">+1</option>
                            <option data-countryCode="UZ" value="7">+7</option>
                            <option data-countryCode="VU" value="678">+678</option>
                            <option data-countryCode="VA" value="379">+379</option>
                            <option data-countryCode="VE" value="58">+58</option>
                            <option data-countryCode="VN" value="84">+84</option>
                            <option data-countryCode="VG" value="84">+1284</option>
                            <option data-countryCode="VI" value="84">+1340</option>
                            <option data-countryCode="WF" value="681">+681</option>
                            <option data-countryCode="YE" value="969">+969</option>
                            <option data-countryCode="YE" value="967">+967</option>
                            <option data-countryCode="ZM" value="260">+260</option>
                            <option data-countryCode="ZW" value="263">+263</option>
                        </select>
                        <input type="text" class="form-control" name="mobile_number" id="mobile_number" placeholder="Phone Number" />
                        <span id="error_mobile_number"></span>
                    </div>
                    <div class="form-group">
                        <i class="fa fa-envelope-o"></i>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Your Email Address" />
                        <span id="error_email"></span>
                    </div>
                    <div class="form-group procedure-dropdown">
                        <i class="fa fa-calendar"></i>
                        <i class="fa fa-angle-down"></i>
                        <select class="form-control" id="topic" name="topic">
                            <option value="">Quando intendi eseguire questa procedura?
</option>
                            <option value="As soon as possible">Il prima possibile
</option>
                            <option value="Within a month">Entro un mese
</option>
                            <option value="Within 3 months">Entro 3 mesi
</option>
                            <option value="Within 6 months">Entro 6 mesi
</option>
                            <option value="Just enquiring">Sto solo chiedendo
</option>
                        </select>
                    </div>
                    <span id="error_procedure"></span>
                    <div class="form-group">
                        <i class="fa fa-envelope-o"></i>
                        <textarea class="form-control" placeholder="Message" id="message" name="message"></textarea>
                        <span id="error_message"></span>
                    </div>
                    <div class="catptcha-btn-group">
                        <div class="captcha-wrapper">
                            <form>
                                <?php
                                $random1 = rand('0', '9');
                                $random2 = rand('0', '9');
                                ?>
                                <span class="number"><?= $random1; ?></span>
                                <span class="operator">+</span>
                                <span class="number"><?= $random2; ?></span>
                                <span class="equal">=</span>
                                <input class="form-control" name="captchaVerify" id="captchaVerify" />

                                <input type="hidden" class="form-control" name="random1" id="random1" value="<?= $random1; ?>" />
                                <input type="hidden" class="form-control" name="random2" id="random2" value="<?= $random2; ?>" />
                            </form>
                        </div>
                        <button type="button" id="submitbtn" value="Home Page" class="btn btn-primary">Invia <i class="fa fa-paper-plane-o "></i>
                    </div>
                    <div id="form_message" style="margin-top:20px; color:white;"></div>
                </form>
            </div>
        </div>
    </div>
    <div class="our-exp-bottom-container">
        <div class="container">
            <div class="clock-timing-list">
                <div class="clock-timing-item">
                    <div class="clock">
                        <div id="clock_uk"></div>
                    </div>
                    <h5>London</h5>
                    <span><?php echo esc_attr(get_option('londontitle')); ?></span>
                    <p><?php echo esc_attr(get_option('londonaddress')); ?></p>
                </div>
                <div class="clock-timing-item">
                    <div class="clock">
                        <div id="clock_istanbul"></div>
                    </div>
                    <h5>Istanbul</h5>
                    <span><?php echo esc_attr(get_option('instanbultitle')); ?></span>
                    <p><?php echo esc_attr(get_option('instanbuladdress')); ?></p>
                </div>
                <div class="clock-timing-item">
                    <div class="clock">
                        <div id="clock_tirana"></div>
                    </div>
                    <h5>Tirana</h5>
                    <span><?php echo esc_attr(get_option('tiranatitle')); ?></span>
                    <p><?php echo esc_attr(get_option('tiranaaddress')); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end get inttouch form-->
<!-- start free consultant section-->
<section class="free-consultant-wrapper">
    <div class="container">
        <div class="text-wrapper">
            <h2 class="white-color">Ottieni la tua CONSULENZA GRATUITA!
</h2>
            <p class="white-color">Curioso di sapere come sarebbe andato il tuo trapianto di capelli? Connettiti con noi oggi e lascia che ti aiutiamo a capire tutto e tutto con l'aiuto di una consulenza gratuita. e lascia che ti diamo i dettagli completi con l'aiuto di una consulenza gratuita.
</p>
        </div>
        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
            <span>
                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                <span class="text">Ottieni una consulenza gratuita
</span>
                <i class="fa fa-chevron-right"></i>
            </span>
        </a>
    </div>
</section>
<!--end free consultant section-->
<?php
get_footer();
