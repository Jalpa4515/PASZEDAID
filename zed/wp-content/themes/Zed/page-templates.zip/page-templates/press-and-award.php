<?php

/**
 * Template Name:  Press and Award Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

<!-- start  breadcrumbs-->
<section class="breadcrumbs">
    <div class="container">
        <ul>
            <li><a href="<?= BASE_URL; ?>">Home <i class="fa fa-angle-right"></i></a></li>
            <li class="active">Media</li>
        </ul>
    </div>
</section>
<!-- end breadcrumbs-->



<!--  viken - 22/01/2021 work start -->
<!-- start press and award tab-->
<section class="our-exp-wrapper media-award-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Our Media</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">We are </span>
                    <span class="black display-inline"> in Media</span>
                </h2>
            </div>
        </div>
        <div class="tab-wrapper mt-0">
            <div class="container">
                <div class="tab-body-wrapper pt-0">
                    <div class="list  mt-0" id="premium-outlet">
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2020/12/Media-1-1.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2020/12/Media-8.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2020/12/Media-5-1.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/fox-40.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/arde-coast-tv.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/thme-times.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/2-news-.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/3-wrd-BTv.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/news-break.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2020/12/logo3.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/02/class.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/streetinsider.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/herald.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/spcoals-insiders.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/top-hustler.png" alt="Market">
                        </span>
                        <span class="award-item">
                            <img src="<?= BASE_URL; ?>/wp-content/uploads/2021/01/gopreneurs.png" alt="Market">
                        </span>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- <section class="our-exp-wrapper media-award-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Our Media</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Take a look at</span>
                    <span class="black display-inline"> our popularity!</span>
                </h2>
            </div>
        </div>
        <div class="tab-wrapper">
            <div class="container">
                <ul class="tab-title-wrapper">
                    <li class="tab-title-item activelink">
                        <a href="javascript:void(0);" data-tag="premium-outlet">
                            Premium Outlets
                        </a>
                    </li>
                    <li class="tab-title-item">
                        <a href="javascript:void(0);" data-tag="newspaper">
                            Newpapers & <br />Major News Sites
                        </a>
                    </li>
                    <li class="tab-title-item">
                        <a href="javascript:void(0);" data-tag="sites">
                            Sites
                        </a>
                    </li>
                    <li class="tab-title-item">
                        <a href="javascript:void(0);" data-tag="financial-seeds">
                            Financial Feeds
                        </a>
                    </li>
                    <li class="tab-title-item">
                        <a href="javascript:void(0);" data-tag="regional-local-news">
                            Regional & Local <br /> News Sites
                        </a>
                    </li>
                    <li class="tab-title-item">
                        <a href="javascript:void(0);" data-tag="indian-news-site">
                            Indian <br />News Sites
                        </a>
                    </li>
                </ul>
                <div class="tab-body-wrapper">
                    <div class="list" id="premium-outlet">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'premiumoutlets',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'in_media',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultpremium = new WP_Query($args);
                        while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>
                            <span class="award-item">
                                <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Market" />
                            </span>

                        <?php
                        endwhile;
                        ?>
                    </div>
                    <div class="list hide" id="newspaper">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'newspapers',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'in_media',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultpremium = new WP_Query($args);
                        while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>
                            <span class="award-item">
                                <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Market" />
                            </span>

                        <?php
                        endwhile;
                        ?>

                    </div>
                    <div class="list hide" id="sites">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'sites',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'in_media',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultpremium = new WP_Query($args);
                        while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>
                            <span class="award-item">
                                <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Market" />
                            </span>

                        <?php
                        endwhile;
                        ?>

                    </div>
                    <div class="list hide" id="financial-seeds">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'financialfeeds',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'in_media',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultpremium = new WP_Query($args);
                        while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>
                            <span class="award-item">
                                <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Market" />
                            </span>

                        <?php
                        endwhile;
                        ?>
                    </div>
                    <div class="list hide" id="regional-local-news">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'regional',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'in_media',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultpremium = new WP_Query($args);
                        while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>
                            <span class="award-item">
                                <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Market" />
                            </span>

                        <?php
                        endwhile;
                        ?>
                    </div>
                    <div class="list hide" id="indian-news-site">
                        <?php
                        $args = array(
                            'meta_query' => array(
                                array(
                                    'key' => 'type',
                                    'value' => 'indiannews',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'post_type' => 'in_media',
                            'posts_per_page' => -1 // this will retrive all the post that is published 
                        );
                        $resultpremium = new WP_Query($args);
                        while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                            <?php $tid = get_the_ID(); ?>
                            <span class="award-item">
                                <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="Market" />
                            </span>

                        <?php
                        endwhile;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->


<!-- end press and award tab-->
<!-- start specialities service slider-->
<!-- <section class="press-tab-wrapper">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Our Press</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Read what they say</span>
                    <span class="black display-inline"> about us!</span>
                </h2>
            </div>
            <div class="press-image-wrapper">
                <?php
                $args = array(
                    'post_type' => 'in_press',
                    'posts_per_page' => -1 // this will retrive all the post that is published 
                );
                $resultpremium = new WP_Query($args);
                while ($resultpremium->have_posts()) : $resultpremium->the_post(); ?>
                    <?php $tid = get_the_ID(); ?>
                    <span class="press-item">
                        <img src="<?php echo $imagepv = wp_get_attachment_url(get_field('image', $teid)); ?>" alt="USA Today" />
                    </span>
                <?php
                endwhile;
                ?>
            </div>
        </div>
    </div>
</section> -->
<!-- start press and award tab-->

<!--  viken - 22/01/2021 work start -->

<section class="our-exp-wrapper press-award-wrapper pt-0">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Our Certificate</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">Fully </span>
                    <span class="black display-inline">Accredited</span>
                </h2>
                <div class="text-center">
                    <p>Each and every hair transplant that is conducted by us is safely done in a JCI accredited hospital, every treatment that’s being performed by us is assured to be as per the highest industry standards and it is also covered by a lifetime warranty that will guarantee your hair will never fall out again.</p>
                </div>
            </div>
        </div>
        <div class="tab-wrapper">

            <div class="container">

                <ul class="tab-title-wrapper">

                    <?php

                    $args = array(
                        'post_type' => 'press_awards',
                        'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $resultt = new WP_Query($args);
                    $i = 1;
                    while ($resultt->have_posts()) : $resultt->the_post();
                        $p_post = get_the_ID();
                        $imagep = wp_get_attachment_url(get_field('image', $p_post));
                    ?>
                        <li class="tab-title-item <?= $i == 1 ? "activelink" : ""; ?>">
                            <a href="javascript:void(0);" data-tag="<?= $p_post ?>">
                                <img src="<?php echo $imagep; ?>" alt="Bagde" />
                            </a>
                        </li>
                    <?php
                        $i++;
                    endwhile;
                    ?>

                </ul>

                <div class="tab-body-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'press_awards',
                        'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $resultt = new WP_Query($args);
                    $i = 1;
                    while ($resultt->have_posts()) : $resultt->the_post();
                        $p_post = get_the_ID();
                    ?>
                        <div class="list <?= $i == 1 ? "" : "hide"; ?>" id="<?= $p_post; ?>">

                            <p><?= get_field('descriptions', $p_post); ?></p>

                            <!-- <div class="text-center view-more-t-center">

                                <a href="<?= get_field('certificate_link', $p_post) ? get_field('certificate_link', $p_post) : "javascript:void(0)"; ?>" class="btn btn-primary btn-readmore">View Certificate <i class="fa fa-eye"></i></a>

                            </div> -->

                        </div>
                    <?php
                        $i++;
                    endwhile;
                    wp_reset_postdata();
                    ?>

                </div>

            </div>

        </div>
    </div>
</section>
<!-- end press and award tab-->
<!-- start our news section-->
<section class="our-exp-wrapper our-news-wrapper pt-0">
    <div class="our-exp-top-container">
        <div class="container">
            <div class="text-panel w-100">
                <div class="text-center">
                    <span class="section-title two-lines">Our News</span>
                </div>
                <h2 class="text-center">
                    <span class="blue display-inline">BlueMagic</span>
                    <span class="black display-inline">News</span>
                </h2>
                <div class="text-center">
                    <p>Since BlueMagic Group has changed the lives of many people, we often tend to come on the news pages being praised for the kind of services we provide.</p>
                </div>
                <div class="blog-list-wrapper">
                    <?php
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 3 // this will retrive all the post that is published 
                    );
                    $resulttc = new WP_Query($args);
                    if ($resulttc->have_posts()) {
                        while ($resulttc->have_posts()) : $resulttc->the_post();
                            $IDr = get_the_ID();
                    ?>
                            <div class="box-list-item">
                                <span class="blog-image">
                                    <img src="<?php echo get_the_post_thumbnail_url($IDr); ?>" alt="Blog" />
                                </span>
                                <span class="blog-date"><?php echo get_the_time('M d, Y', $IDr); ?></span>
                                <h4><?php echo get_the_title($IDr); ?></h4>
                                <a href="<?= get_the_permalink($IDr); ?>">Read more <i class="fa fa-long-arrow-right"></i></a>
                            </div>
                    <?php
                        endwhile;
                    }
                    ?>

                </div>
                <div class="text-center">
                    <a href="<?= BASE_URL . 'blog'; ?>" class="btn btn-primary btn-readmore">View more <i class="fa fa-long-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end our news section-->

<!-- start free consultant section-->
<section class="free-consultant-wrapper">
    <div class="container">
        <div class="text-wrapper">
            <h2 class="white-color">Hair transplant in mind?</h2>
            <h2 class="white-color">Get a FREE CONSULTATION!</h2>
            <p class="white-color">We are here to clear all your doubts, queries and help you understand which treatment will suit you the best, feel free to contact us!</p>
        </div>
        <a href="https://bluemagiclinic.com/software/form_step1" target="_blank" class="conultant-btn">
            <span>
                <i class="profile"><img src="<?php echo bloginfo('template_directory'); ?>/images/blu-bg.png" alt="Profie" /></i>
                <span class="text">Get free consultation</span>
                <i class="fa fa-chevron-right"></i>
            </span>
        </a>
    </div>
</section>
<!--end free consultant section-->
<?php
get_footer();
